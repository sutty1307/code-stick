#!/usr/bin/env python3
"""Build the offline fork with the matching, verified publisher native runtime.

This is a source-JavaScript rebuild, not a new native compilation. The publisher
APK pins the same React Native 0.86.3, Expo SDK 57 and Hermes bytecode 98 runtime.
All DEX files and native .so files are kept byte-for-byte unchanged. Only the
application bundle, embedded assets/config, labels and manifest are changed.
Private signing files must be kept outside the source tree and distribution.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile

PUBLISHER_SHA256 = 'ec051d90bc9f82587a726b525976494bacef50bc8a7dd0e3789b859373121753'
ANDROID = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ANDROID)


def run(*cmd, **kwargs):
    subprocess.run(list(map(str, cmd)), check=True, **kwargs)


def digest(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1024 * 1024), b''):
            h.update(b)
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--publisher-apk', type=Path, required=True)
    p.add_argument('--apktool', type=Path, required=True)
    p.add_argument('--android-build-tools', type=Path, required=True)
    p.add_argument('--keystore', type=Path, required=True)
    p.add_argument('--password-file', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--work-dir', type=Path)
    args = p.parse_args()
    root = Path(__file__).resolve().parent.parent
    if digest(args.publisher_apk) != PUBLISHER_SHA256:
        raise SystemExit('Publisher APK SHA-256 does not match the pinned release.')
    package = json.loads((root / 'package.json').read_text())
    if package['dependencies']['react-native'] != '0.86.3':
        raise SystemExit('Native runtime mismatch: requires React Native 0.86.3.')
    with zipfile.ZipFile(args.publisher_apk) as z:
        config = json.loads(z.read('assets/app.config'))
        if config.get('sdkVersion') != '57.0.0':
            raise SystemExit('Native runtime mismatch: requires Expo SDK 57.')
        if struct.unpack_from('<I', z.read('assets/index.android.bundle'), 8)[0] != 98:
            raise SystemExit('Native runtime mismatch: requires Hermes bytecode 98.')

    env = {**os.environ, 'CI': '1', 'NODE_ENV': 'production', 'EXPO_NO_TELEMETRY': '1'}
    public_config = subprocess.check_output(
        ['npx', 'expo', 'config', '--type', 'public', '--json'], cwd=root, env=env)
    public = json.loads(public_config)
    application_name = public.get('name')
    version_name = public.get('version')
    android = public.get('android', {})
    version_code = android.get('versionCode')
    new_id = android.get('package')
    scheme = public.get('scheme')
    if not isinstance(application_name, str) or not application_name.strip() or '\n' in application_name:
        raise SystemExit('Public app config must have a non-empty single-line name.')
    if not isinstance(version_name, str) or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9.+_-]{0,79}', version_name):
        raise SystemExit('Public app config must have a valid Android version name.')
    if type(version_code) is not int or not 1 <= version_code <= 2100000000:
        raise SystemExit('Public app config must define a positive Android versionCode.')
    if not isinstance(new_id, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*(?:\.[A-Za-z][A-Za-z0-9_]*)+', new_id):
        raise SystemExit('Public app config must define a valid Android package.')
    if not isinstance(scheme, str) or not re.fullmatch(r'[a-z][a-z0-9+.-]*', scheme):
        raise SystemExit('Public app config must define a single valid URI scheme.')

    work = args.work_dir or Path(tempfile.mkdtemp(prefix='ai-drive-apk-'))
    work.mkdir(parents=True, exist_ok=True)
    decoded = work / 'decoded'
    if decoded.exists():
        shutil.rmtree(decoded)
    run('java', '-jar', args.apktool, 'd', '--no-src', args.publisher_apk, '-o', decoded)
    assets = work / 'source-assets'
    if assets.exists():
        shutil.rmtree(assets)
    assets.mkdir(exist_ok=True)
    bundle_assets = work / 'bundle-assets'
    if bundle_assets.exists():
        shutil.rmtree(bundle_assets)
    bundle_assets.mkdir(exist_ok=True)
    js = bundle_assets / 'index.android.bundle'
    run('npx', 'expo', 'export:embed', '--platform', 'android', '--dev', 'false',
        '--bytecode', '--entry-file', 'node_modules/expo-router/entry.js',
        '--bundle-output', js, '--assets-dest', assets, '--max-workers', '4', cwd=root, env=env)
    if struct.unpack_from('<I', js.read_bytes(), 8)[0] != 98:
        raise SystemExit('New source bundle has incompatible Hermes bytecode.')
    shutil.copytree(bundle_assets, decoded / 'assets', dirs_exist_ok=True)
    # Metro exports Android assets into drawable-*/raw plus font assets.
    for directory in assets.iterdir():
        if directory.is_dir():
            destination = decoded / ('assets' if directory.name == 'assets' else 'res') / directory.name
            if directory.name == 'assets':
                destination = decoded / 'assets'
            shutil.copytree(directory, destination, dirs_exist_ok=True)
        else:
            shutil.copyfile(directory, decoded / 'assets' / directory.name)

    (decoded / 'assets/app.config').write_bytes(public_config)
    manifest_path = decoded / 'AndroidManifest.xml'
    tree = ET.parse(manifest_path)
    manifest = tree.getroot()
    original_id = manifest.get('package')
    manifest.set('package', new_id)
    manifest.set(f'{{{ANDROID}}}versionCode', str(version_code))
    manifest.set(f'{{{ANDROID}}}versionName', version_name)
    blocked = {
        'android.permission.INTERNET', 'android.permission.ACCESS_NETWORK_STATE',
        'com.google.android.c2dm.permission.RECEIVE',
        'com.google.android.finsky.permission.BIND_GET_INSTALL_REFERRER_SERVICE',
    }
    for child in list(manifest):
        if child.tag == 'uses-permission' and child.get(f'{{{ANDROID}}}name') in blocked:
            manifest.remove(child)
    # Keep fully qualified original class names: the native shell is unchanged.
    # Provider authorities and app-specific permissions must use the fork ID.
    for element in manifest.iter():
        for key, value in list(element.attrib.items()):
            local = key.rsplit('}', 1)[-1]
            if local in ('authorities', 'taskAffinity') or element.tag in ('permission', 'uses-permission'):
                element.set(key, value.replace(original_id, new_id))
            if element.tag == 'data' and local == 'scheme' and value == 'chatterui':
                element.set(key, scheme)
    application = manifest.find('application')
    application.set(f'{{{ANDROID}}}allowBackup', 'false')
    application.set(f'{{{ANDROID}}}usesCleartextTraffic', 'false')
    application.set(f'{{{ANDROID}}}debuggable', 'false')
    application.attrib.pop(f'{{{ANDROID}}}networkSecurityConfig', None)
    for metadata in application.findall('meta-data'):
        name = metadata.get(f'{{{ANDROID}}}name', '')
        if name == 'expo.modules.updates.ENABLED':
            metadata.set(f'{{{ANDROID}}}value', 'false')
        if name == 'expo.modules.updates.EXPO_UPDATES_CHECK_ON_LAUNCH':
            metadata.set(f'{{{ANDROID}}}value', 'NEVER')
    for activity in application.findall('activity'):
        if activity.get(f'{{{ANDROID}}}name') == 'com.processtext.ProcessTextActivity':
            activity.set(f'{{{ANDROID}}}label', f'Ask {application_name}')
    tree.write(manifest_path, encoding='utf-8', xml_declaration=True)
    strings = decoded / 'res/values/strings.xml'
    st = ET.parse(strings)
    for s in st.getroot():
        if s.get('name') == 'app_name':
            s.text = application_name
    st.write(strings, encoding='utf-8', xml_declaration=True)
    yml = decoded / 'apktool.yml'
    versioned_yaml = yml.read_text()
    for key, value in (('versionCode', version_code), ('versionName', version_name)):
        versioned_yaml, count = re.subn(
            rf'(?m)^([ \t]*{key}:)[^\r\n]*$',
            lambda match: f'{match[1]} {value}', versioned_yaml)
        if count != 1:
            raise SystemExit(f'Expected exactly one apktool {key}; found {count}.')
    yml.write_text(versioned_yaml)
    unsigned = work / 'unsigned.apk'
    aligned = work / 'aligned.apk'
    run('java', '-jar', args.apktool, 'b', decoded, '-o', unsigned)
    run(args.android_build_tools / 'zipalign', '-f', '-P', '16', '4', unsigned, aligned)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    # apksigner consumes successive lines when the same password file is used
    # twice. An isolated subprocess variable lets store/key use the same secret
    # without printing it or requiring a duplicated plaintext line on disk.
    signing_env = {**os.environ, 'AI_DRIVE_APK_SIGNING_PASSWORD': args.password_file.read_text().strip()}
    run(args.android_build_tools / 'apksigner', 'sign', '--ks', args.keystore,
        '--ks-key-alias', 'ai-drive-offline', '--ks-pass', 'env:AI_DRIVE_APK_SIGNING_PASSWORD',
        '--key-pass', 'env:AI_DRIVE_APK_SIGNING_PASSWORD', '--out', args.output, aligned, env=signing_env)
    run(args.android_build_tools / 'apksigner', 'verify', '--verbose', '--print-certs', args.output)
    with zipfile.ZipFile(args.publisher_apk) as original, zipfile.ZipFile(args.output) as final:
        bad_member = final.testzip()
        if bad_member:
            raise SystemExit(f'APK ZIP CRC failed: {bad_member}')
        preserved = [n for n in original.namelist() if n.endswith('.dex') or n.startswith('lib/') and n.endswith('.so')]
        for name in preserved:
            if original.read(name) != final.read(name):
                raise SystemExit(f'Unexpected native runtime change: {name}')
        abis = sorted({n.split('/')[1] for n in final.namelist() if n.startswith('lib/') and n.endswith('.so')})
        if abis != ['arm64-v8a']:
            raise SystemExit(f'Unexpected APK architecture: {abis}')
    badging = subprocess.check_output([str(args.android_build_tools / 'aapt'), 'dump', 'badging', str(args.output)], text=True)
    final_identity = re.search(
        r"^package: name='([^']+)' versionCode='(\d+)' versionName='([^']+)'", badging, re.MULTILINE)
    if not final_identity or final_identity.groups() != (new_id, str(version_code), version_name):
        raise SystemExit('Final APK identity/version does not match the public app config.')
    final_label = re.search(r"^application-label:'(.*)'$", badging, re.MULTILINE)
    if not final_label or final_label[1] != application_name:
        raise SystemExit('Final APK application name does not match the public app config.')
    if "sdkVersion:'24'" not in badging:
        raise SystemExit('Unexpected final minimum Android SDK.')
    for permission in blocked:
        if f"uses-permission: name='{permission}'" in badging:
            raise SystemExit(f'Offline manifest violation: {permission}')
    compiled_manifest = subprocess.check_output([
        str(args.android_build_tools / 'aapt'), 'dump', 'xmltree', str(args.output), 'AndroidManifest.xml'
    ], text=True)
    manifest_lines = compiled_manifest.splitlines()
    for attribute in ('allowBackup', 'usesCleartextTraffic', 'debuggable'):
        matches = [line for line in manifest_lines if f'android:{attribute}(' in line]
        if len(matches) != 1 or '(type 0x12)0x0' not in matches[0]:
            raise SystemExit(f'Offline manifest violation: {attribute} is not false.')
    update_line = next(i for i, line in enumerate(manifest_lines) if 'expo.modules.updates.ENABLED' in line)
    if '(type 0x12)0x0' not in manifest_lines[update_line + 1]:
        raise SystemExit('Offline manifest violation: Expo updates enabled.')
    with zipfile.ZipFile(args.output) as final:
        if any(name.endswith(('.keystore', '.jks', '.p12', '.password')) for name in final.namelist()):
            raise SystemExit('Signing file unexpectedly included in APK.')
    run(args.android_build_tools / 'zipalign', '-c', '-P', '16', '4', args.output)
    final_sha = digest(args.output)
    provenance = {
        'build_method': 'Source Metro/Hermes bundle with verified matching publisher native shell',
        'application_id': new_id,
        'application_name': application_name,
        'version': version_name,
        'version_code': version_code,
        'apk_sha256': final_sha,
        'publisher_native_apk_sha256': PUBLISHER_SHA256,
        'source_package_lock_sha256': digest(root / 'package-lock.json'),
        'source_public_config_sha256': hashlib.sha256(public_config).hexdigest(),
        'source_bundle_sha256': digest(js),
        'react_native': '0.86.3', 'expo_sdk': '57.0.0', 'hermes_bytecode': 98,
        'preserved_dex_and_native_files': len(preserved),
        'native_files_byte_identical': True,
        'zip_crc_verified': True, 'zip_alignment_verified': True,
        'architecture': abis, 'minimum_android_sdk': 24,
        'internet_permission': False, 'network_state_permission': False,
        'allow_backup': False, 'cleartext_traffic': False,
        'debuggable': False, 'ota_updates': False,
        'private_signing_key_included': False,
        'actual_android_phone_tested': False,
    }
    args.output.with_suffix('.build.json').write_text(json.dumps(provenance, indent=2) + '\n')
    print(f'Built {args.output.name}; preserved {len(preserved)} native files; SHA-256 {final_sha}')


if __name__ == '__main__':
    main()
