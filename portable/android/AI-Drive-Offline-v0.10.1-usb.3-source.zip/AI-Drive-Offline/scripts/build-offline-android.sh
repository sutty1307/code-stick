#!/usr/bin/env bash
set -euo pipefail

# Build the Android-only offline fork. Keep signing keys outside this source tree.
# Requirements: Node/npm, JDK 17+, Android SDK (platform 36, build-tools 36,
# NDK 27.1.12297006, CMake 3.22.1). Honor inherited proxy and CA settings.
task_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$task_root"
: "${JAVA_HOME:?Set JAVA_HOME to your JDK directory}"
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-$ANDROID_HOME}"
export NODE_ENV=production
export CI=1

if [[ ! -d node_modules ]]; then npm ci --no-audit --no-fund; fi
if [[ ! -d android ]]; then npx expo prebuild --platform android --no-install; fi

cd android
./gradlew :app:assembleRelease --no-daemon --max-workers=4 \
  -PreactNativeArchitectures=arm64-v8a \
  -PEX_DEV_CLIENT_NETWORK_INSPECTOR=false "$@"
printf 'Build output directory: %s\n' "$task_root/android/app/build/outputs/apk/release"
printf 'Sign with your own private key and verify the final manifest before distributing.\n'
