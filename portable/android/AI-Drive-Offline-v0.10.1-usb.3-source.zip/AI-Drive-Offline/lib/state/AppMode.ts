import { create } from 'zustand'
import { persist } from 'zustand/middleware'
import { useShallow } from 'zustand/react/shallow'

import { Storage } from '@lib/enums/Storage'
import { createMMKVStorage } from '@lib/storage/MMKV'

type AppMode = 'local' | 'remote'
type AppModeStateProps = {
    appMode: AppMode
    setAppMode: (mode: AppMode) => void
}

/** Remote mode cannot be enabled by a restored preference, route, or older app data. */
export const useAppModeStore = create<AppModeStateProps>()(
    persist(
        (set) => ({
            appMode: 'local',
            setAppMode: () => set({ appMode: 'local' }),
        }),
        {
            name: Storage.AppMode,
            storage: createMMKVStorage(),
            partialize: () => ({ appMode: 'local' }),
            merge: (_saved, current) => ({ ...current, appMode: 'local' }),
            version: 1,
        }
    )
)

export const useAppMode = () =>
    useAppModeStore(
        useShallow((state) => ({ appMode: state.appMode, setAppMode: state.setAppMode }))
    )
