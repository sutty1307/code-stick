import type { Voice } from 'expo-speech'
import { create } from 'zustand'
import { persist } from 'zustand/middleware'

import { Storage } from '@lib/enums/Storage'
import { createMMKVStorage } from '@lib/storage/MMKV'

type TTSState = {
    activeSwipeId?: number
    voice?: Voice
    enabled: boolean
    auto: boolean
    rate: number
    startTTS: (text: string, swipeId: number) => Promise<void>
    stopTTS: () => Promise<void>
    setEnabled: (b: boolean) => void
    setAuto: (b: boolean) => void
    setVoice: (v: Voice) => void
    setRate: (r: number) => void
    setLiveTTS: (b: boolean) => void
    speak: (text: string, onDone?: () => void, onStop?: () => void) => void
    handleEndGeneration: (swipeId: number, text: string) => Promise<void>
    handleStartGeneration: (swipeId: number) => void
    liveTTS: boolean
    pauseLive?: boolean
    setPauseLive: (b: boolean) => void
    buffer: string
    clearAndRunBuffer: (lastIndex: number) => void
    clearBuffer: () => void
    insertBuffer: (text: string) => void
}

/** Android speech engines are separate apps and may use a network. Never pass them chat text. */
export const useTTSStore = create<TTSState>()(
    persist(
        (set) => ({
            voice: undefined,
            enabled: false,
            auto: false,
            liveTTS: false,
            rate: 1,
            activeSwipeId: undefined,
            pauseLive: false,
            buffer: '',
            startTTS: async () => {},
            stopTTS: async () => set({ activeSwipeId: undefined, buffer: '' }),
            setEnabled: () => set({ enabled: false }),
            setAuto: () => set({ auto: false }),
            setVoice: () => set({ voice: undefined }),
            setRate: () => set({ rate: 1 }),
            setLiveTTS: () => set({ liveTTS: false }),
            setPauseLive: () => set({ pauseLive: false }),
            speak: (_text, onDone) => {
                onDone?.()
            },
            handleEndGeneration: async () => {},
            handleStartGeneration: () => {},
            clearAndRunBuffer: () => set({ buffer: '', activeSwipeId: undefined }),
            clearBuffer: () => set({ buffer: '' }),
            insertBuffer: () => {},
        }),
        {
            name: Storage.TTS,
            storage: createMMKVStorage(),
            version: 1,
            partialize: () => ({ enabled: false, auto: false, liveTTS: false }),
            merge: (_saved, current) => ({
                ...current,
                voice: undefined,
                enabled: false,
                auto: false,
                liveTTS: false,
                activeSwipeId: undefined,
                pauseLive: false,
                rate: 1,
                buffer: '',
            }),
        }
    )
)
