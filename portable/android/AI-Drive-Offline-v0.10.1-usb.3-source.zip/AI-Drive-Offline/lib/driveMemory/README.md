# USB memory core

`driveMemory` uses Android's Storage Access Framework to read and write a selected removable-storage folder. It rejects internal phone storage and cloud document providers. The app remembers only the folder URI through `DeviceGrants`; this module has no phone-file or network fallback.

-   `selectFolder()` selects, verifies and connects a USB folder. Cancellation returns `false`.
-   `ensureReady()` / `refresh()` re-read the drive; use these before inference or displaying archives.
-   `getState()` / `subscribe(listener)` report verified revisions, entries, errors and recovery. A failed read or write clears cached private data and throws `DriveMemoryError`.
-   `saveManualEntry`, `updateEntry`, `removeEntry` manage facts, preferences and notes. Explicit forget operations replace both recovery slots; past conversation text remains until that conversation is separately removed.
-   `captureUserMessage` saves only explicit “remember”, preference, name, pronoun or residence statements from user messages. It never mines assistant replies. Entries retain source conversation/message IDs. When a message ID is supplied, its processed marker remains on the USB after forgetting the entry; rescanning old history cannot silently recreate that entry. A new user statement with a new ID can still be remembered.
-   `getPromptMemory(query, maxChars)` builds a bounded, JSON-quoted reference after `ensureReady`. It escapes Llama/ChatML role delimiters and states that saved text is data, not instructions.
-   `archiveConversation`, `recordTurn`, `listConversations`, `getConversation`, `removeConversation` store complete chat snapshots.
-   `setApplicationState` / `getApplicationState` preserve the caller's JSON state for restoring RAM-only profiles, characters, settings and chat databases.
-   `disconnect()` forgets the phone's selected-folder URI and clears memory; it does not erase USB files.

Writes alternate between `drive-memory-a.json` and `drive-memory-b.json`. Each envelope contains a SHA-256 checksum over the versioned JSON body. The inactive slot is written and read back exactly before a revision is reported as saved. A valid prior revision can be recovered when its partner is corrupt. Both corrupt snapshots cause a clear error and are preserved for recovery. Checksums detect corruption; they do not authenticate or encrypt files. Android's file API does not expose a filesystem flush guarantee, so a verified read-back is not a power-loss guarantee.

Memory entries are limited to 2,000 characters and 1,000 entries. The complete persisted JSON envelope is limited to 33,554,432 JavaScript string characters (UTF-16 code units), not 32 MiB of UTF-8 bytes. Hitting a limit fails the save; it never truncates chat history. Full application state can include sensitive conversation text. Store only JSON-compatible state, not runtime callbacks or access tokens.

The pure core tests use an injected drive adapter and run without Expo:

```sh
node --test lib/driveMemory/core.test.cjs
```

Actual USB permissions, detach behavior and file-provider compatibility still require testing on a physical Android phone. A directory URI is a device-specific Android grant; on another phone the user must select the same USB folder again.
