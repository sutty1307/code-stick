import { useCallback, useSyncExternalStore } from 'react'

import { mmkv } from './MMKV'

type Update<T> = T | undefined | ((previous: T | undefined) => T | undefined)

function useSetting<T extends string | boolean | number>(
    key: string,
    read: (key: string) => T | undefined
) {
    const subscribe = useCallback(
        (notify: () => void) =>
            mmkv.subscribe((changed) => {
                if (changed === key) notify()
            }),
        [key]
    )
    const get = useCallback(() => read(key), [key, read])
    const value = useSyncExternalStore(subscribe, get, get)
    const set = useCallback(
        (update: Update<T>) => {
            const next = typeof update === 'function' ? update(read(key)) : update
            if (next === undefined) mmkv.remove(key)
            else mmkv.set(key, next)
        },
        [key, read]
    )
    return [value, set] as const
}
const readBoolean = (key: string) => mmkv.getBoolean(key)
const readNumber = (key: string) => mmkv.getNumber(key)
const readString = (key: string) => mmkv.getString(key)
export const useMMKVBoolean = (key: string) => useSetting(key, readBoolean)
export const useMMKVNumber = (key: string) => useSetting(key, readNumber)
export const useMMKVString = (key: string) => useSetting(key, readString)
