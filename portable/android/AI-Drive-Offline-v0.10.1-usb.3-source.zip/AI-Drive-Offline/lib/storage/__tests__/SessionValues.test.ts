import { AppSettings } from '../../constants/GlobalValues'
import { SessionValues, SessionValue } from '../SessionValues'

const privateSettings = new Set([
    AppSettings.SaveLocalKV,
    AppSettings.PrintContext,
    AppSettings.ShowNotificationText,
])

describe('USB session settings snapshots', () => {
    test('primitive values survive JSON serialization and replace the preceding session', () => {
        const original = new SessionValues()
        original.set('model-path', 'content://drive/llama.gguf')
        original.set('context', 2048)
        original.set('dark-mode', false)
        original.set('empty-value', '')
        original.set('zero-value', 0)

        const replacement = new SessionValues()
        replacement.set('previous-drive', 'must disappear')
        replacement.restore(JSON.parse(JSON.stringify(original.snapshot())))

        expect(replacement.getString('model-path')).toBe('content://drive/llama.gguf')
        expect(replacement.getNumber('context')).toBe(2048)
        expect(replacement.getBoolean('dark-mode')).toBe(false)
        expect(replacement.getString('empty-value')).toBe('')
        expect(replacement.getNumber('zero-value')).toBe(0)
        expect(replacement.contains('previous-drive')).toBe(false)
        expect(replacement.snapshot()).toEqual(original.snapshot())
        expect(replacement.getNumber('model-path')).toBeUndefined()
        expect(replacement.getString('context')).toBeUndefined()
        expect(replacement.getBoolean('context')).toBeUndefined()
    })

    test('editing an exported snapshot cannot change in-memory settings', () => {
        const settings = new SessionValues()
        settings.set('model-name', 'Llama')
        const exported = settings.snapshot()
        exported['model-name'] = 'Another model'
        exported['injected'] = true
        expect(settings.getString('model-name')).toBe('Llama')
        expect(settings.contains('injected')).toBe(false)
    })

    test.each([...privateSettings])(
        '%s cannot be enabled directly or by a drive snapshot',
        (key) => {
            const settings = new SessionValues(privateSettings)
            const observed: Array<boolean | undefined> = []
            settings.subscribe((changed) => {
                if (changed === key) observed.push(settings.getBoolean(key))
            })

            settings.set(key, true)
            expect(settings.getBoolean(key)).toBe(false)
            settings.set(key, 'true')
            expect(settings.snapshot()[key]).toBe(false)
            settings.restore({ [key]: true, harmless: true })
            expect(settings.getBoolean(key)).toBe(false)
            expect(settings.getBoolean('harmless')).toBe(true)
            expect(JSON.parse(JSON.stringify(settings.snapshot()))[key]).toBe(false)
            expect(observed).not.toContain(true)
        }
    )

    test.each([
        null,
        undefined,
        true,
        2048,
        'not a snapshot',
        [],
        ['value'],
        { legitimate: 'new value', invalid: null },
        { legitimate: 'new value', invalid: {} },
        { legitimate: 'new value', invalid: [] },
        { legitimate: 'new value', invalid: undefined },
        { legitimate: 'new value', invalid: () => true },
        { legitimate: 'new value', invalid: Number.NaN },
        { legitimate: 'new value', invalid: Number.POSITIVE_INFINITY },
        { legitimate: 'new value', invalid: Number.NEGATIVE_INFINITY },
        { ['x'.repeat(513)]: 'too long' },
    ])('an invalid restore leaves the complete previous session intact: %p', (invalid) => {
        const settings = new SessionValues(privateSettings)
        settings.set('theme', 'dark')
        settings.set('context', 2048)
        settings.set(AppSettings.PrintContext, true)
        const previous = settings.snapshot()
        const subscriber = jest.fn()
        settings.subscribe(subscriber)

        expect(() => settings.restore(invalid as Record<string, SessionValue>)).toThrow(
            'Invalid drive settings'
        )
        expect(settings.snapshot()).toEqual(previous)
        expect(subscriber).not.toHaveBeenCalled()
    })

    test('an excessive settings object is rejected before removing current values', () => {
        const settings = new SessionValues()
        settings.set('current', 'keep me')
        const excessive = Object.fromEntries(
            Array.from({ length: 10001 }, (_, index) => [`setting-${index}`, true])
        )
        expect(() => settings.restore(excessive)).toThrow('Invalid drive settings')
        expect(settings.snapshot()).toEqual({ current: 'keep me' })
    })

    test('subscribers see changed, removed, and newly restored settings', () => {
        const settings = new SessionValues()
        settings.set('theme', 'dark')
        settings.set('previous-drive', 'old')
        const changes: string[] = []
        const unsubscribe = settings.subscribe((key) => changes.push(key))
        const secondListener = jest.fn()
        const registration = settings.addOnValueChangedListener(secondListener)

        settings.restore({ theme: 'light', context: 2048 })

        expect(new Set(changes)).toEqual(new Set(['theme', 'previous-drive', 'context']))
        expect(secondListener).toHaveBeenCalledWith('theme')
        expect(secondListener).toHaveBeenCalledWith('previous-drive')
        expect(secondListener).toHaveBeenCalledWith('context')
        expect(settings.snapshot()).toEqual({ theme: 'light', context: 2048 })

        unsubscribe()
        registration.remove()
        changes.length = 0
        secondListener.mockClear()
        settings.restore({ theme: 'dark' })
        expect(changes).toHaveLength(0)
        expect(secondListener).not.toHaveBeenCalled()
    })

    test('restoring an empty snapshot removes session values and informs their subscribers', () => {
        const settings = new SessionValues()
        settings.set('theme', 'dark')
        const subscriber = jest.fn()
        settings.subscribe(subscriber)
        settings.restore({})
        expect(settings.getAllKeys()).toEqual([])
        expect(settings.snapshot()).toEqual({})
        expect(subscriber).toHaveBeenCalledWith('theme')
    })

    test('logger contents are never included in the exported settings snapshot', () => {
        const settings = new SessionValues()
        settings.set('theme', 'dark')
        settings.set('logstate-storage', JSON.stringify({ privatePrompt: 'sensitive chat text' }))
        const snapshot = settings.snapshot()
        expect(snapshot).toEqual({ theme: 'dark' })
        expect(JSON.stringify(snapshot)).not.toContain('sensitive chat text')

        settings.restore({ theme: 'light', 'logstate-storage': 'older drive logs' })
        expect(settings.snapshot()).toEqual({ theme: 'light' })
    })
})
