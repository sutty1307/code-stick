export type SessionValue = string | number | boolean

/** Personal settings live in RAM; driveIntegration persists this snapshot to USB. */
export class SessionValues {
    private values = new Map<string, SessionValue>()
    private listeners = new Set<(key: string) => void>()

    constructor(private readonly blocked = new Set<string>()) {}

    set(key: string, value: SessionValue) {
        if (this.blocked.has(key)) value = false
        if (typeof value === 'number' && !Number.isFinite(value)) throw new Error('Invalid setting')
        if (this.values.get(key) === value) return
        this.values.set(key, value)
        this.emit(key)
    }
    getString(key: string) {
        const value = this.values.get(key)
        return typeof value === 'string' ? value : undefined
    }
    getNumber(key: string) {
        const value = this.values.get(key)
        return typeof value === 'number' ? value : undefined
    }
    getBoolean(key: string) {
        const value = this.values.get(key)
        return typeof value === 'boolean' ? value : undefined
    }
    contains(key: string) {
        return this.values.has(key)
    }
    getAllKeys() {
        return [...this.values.keys()]
    }
    remove(key: string) {
        if (this.values.delete(key)) this.emit(key)
    }
    clearAll() {
        const keys = this.getAllKeys()
        this.values.clear()
        keys.forEach((key) => this.emit(key))
    }
    subscribe(callback: (key: string) => void) {
        this.listeners.add(callback)
        return () => {
            this.listeners.delete(callback)
        }
    }
    addOnValueChangedListener(callback: (key: string) => void) {
        return { remove: this.subscribe(callback) }
    }
    snapshot(): Record<string, SessionValue> {
        return Object.fromEntries([...this.values].filter(([key]) => key !== 'logstate-storage'))
    }
    restore(snapshot: Record<string, SessionValue>) {
        if (!snapshot || typeof snapshot !== 'object' || Array.isArray(snapshot))
            throw new Error('Invalid drive settings')
        const entries = Object.entries(snapshot)
        if (
            entries.length > 10000 ||
            entries.some(
                ([key, value]) =>
                    key.length > 512 ||
                    !['string', 'number', 'boolean'].includes(typeof value) ||
                    (typeof value === 'number' && !Number.isFinite(value))
            )
        )
            throw new Error('Invalid drive settings')
        this.clearAll()
        entries.forEach(([key, value]) => this.set(key, value))
    }
    private emit(key: string) {
        this.listeners.forEach((listener) => listener(key))
    }
}
