import { createMMKV } from 'react-native-mmkv'

// Contains only Android's selected USB folder URI, never conversations or profiles.
export const deviceGrants = createMMKV({ id: 'ai-drive-folder-grants' })
