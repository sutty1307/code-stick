import { createJSONStorage, StateStorage } from 'zustand/middleware'

import { AppSettings } from '@lib/constants/GlobalValues'

import { SessionValues } from './SessionValues'

export const mmkv = new SessionValues(
    new Set([AppSettings.SaveLocalKV, AppSettings.PrintContext, AppSettings.ShowNotificationText])
)

export const mmkvStorage: StateStorage = {
    setItem: (name, value) => {
        return mmkv.set(name, value)
    },
    getItem: (name) => {
        const value = mmkv.getString(name)
        return value ?? null
    },
    removeItem: (name) => {
        return mmkv.remove(name)
    },
}

export const createMMKVStorage = () => {
    return createJSONStorage(() => mmkvStorage)
}
