import { AppSettings } from '@lib/constants/GlobalValues'
import { APIManager } from '@lib/engine/API/APIManagerState'
import { Llama } from '@lib/engine/Local/LlamaLocal'
import { KV } from '@lib/engine/Local/Model'
import { Tokenizer } from '@lib/engine/Tokenizer'
import { useTextFilterStore } from '@lib/hooks/TextFilter'
import { useAppModeStore } from '@lib/state/AppMode'
import { useBackgroundStore } from '@lib/state/BackgroundImage'
import { Characters } from '@lib/state/Characters'
import { CharacterSorter } from '@lib/state/CharacterSorter'
import { Chats, useInference } from '@lib/state/Chat'
import { ChatStyle } from '@lib/state/ChatStyle'
import { useChatInputTextStore } from '@lib/state/components/ChatInput'
import { Instructs } from '@lib/state/Instructs'
import { Logger } from '@lib/state/Logger'
import { useLorebookPreferenceStore } from '@lib/state/lorebooks/state'
import { SamplersManager } from '@lib/state/SamplerState'
import { TagHider } from '@lib/state/TagHider'
import { useTTSStore } from '@lib/state/TTS'
import { mmkv } from '@lib/storage/MMKV'
import { Theme } from '@lib/theme/ThemeManager'
import { initializeDefaultData } from '@lib/utils/Startup'

import {
    activateDriveDatabaseSync,
    clearDriveAssets,
    clearDriveDatabase,
    isDriveSessionReady,
    onDriveUnavailable,
    pauseDriveDatabaseSync,
    requireDriveSession,
    restoreDriveApplicationState,
    syncDriveDatabase,
    waitForDriveDatabaseSync,
    getDriveSessionGeneration,
    seedDriveConversationCache,
} from './driveDatabase'
import { driveMemory, DriveMemoryError } from './driveMemory'
import { dispatchDriveCommand, DriveToolStorage } from './driveTools'

type PersistentStore = {
    getInitialState(): object
    setState(state: object, replace: true): void
    persist?: { rehydrate(): Promise<void> | void }
}
function copyInitial(value: unknown): unknown {
    if (Array.isArray(value)) return value.map(copyInitial)
    if (value && typeof value === 'object')
        return Object.fromEntries(
            Object.entries(value).map(([key, item]) => [key, copyInitial(item)])
        )
    return value
}
const stores = [
    Characters.useUserStore,
    Instructs.useInstruct,
    Llama.useLlamaPreferencesStore,
    SamplersManager.useSamplerStore,
    ChatStyle.useChatStyle,
    Theme.useColorState,
    CharacterSorter.useSorterStore,
    useTTSStore,
    TagHider.useTagHiderStore,
    useBackgroundStore,
    useAppModeStore,
    useLorebookPreferenceStore,
    useTextFilterStore,
    APIManager.useConnectionsStore,
    KV.useKVStore,
].map((store) => {
    const typed = store as unknown as PersistentStore
    return { store: typed, initial: copyInitial(typed.getInitialState()) as object }
})

let lifecycle: Promise<void> = Promise.resolve()
function serial<T>(operation: () => Promise<T>): Promise<T> {
    const next = lifecycle.then(operation)
    lifecycle = next.then(
        () => undefined,
        () => undefined
    )
    return next
}

async function stopGeneration(): Promise<void> {
    const inference = useInference.getState()
    if (inference.nowGenerating) {
        await inference.abortFunction()
        await useInference.getState().stopGenerating()
    }
}

/** Release native contexts before erasing their cached assets and personal JS state. */
async function clearPrivateSession(): Promise<void> {
    pauseDriveDatabaseSync()
    await waitForDriveDatabaseSync()
    await stopGeneration()
    await Llama.useLlamaModelStore.getState().unload()
    const tokenizer = Tokenizer.useTokenizerState.getState().model
    if (tokenizer) await tokenizer.release()
    Tokenizer.useTokenizerState.setState({ model: undefined })
    Chats.useChatState.setState({ id: undefined, buffer: { data: '' }, scrollData: undefined })
    useInference.setState({
        nowGenerating: false,
        currentSwipeId: undefined,
        abortFunction: () => {},
    })
    useChatInputTextStore.getState().setText('')
    Characters.useCharacterStore.getState().unloadCard()
    Characters.useUserStore.getState().unloadCard()
    for (const { store, initial } of stores) store.setState(copyInitial(initial) as object, true)
    Logger.useLoggerStore.getState().flushLogs()
    mmkv.clearAll()
    clearDriveDatabase()
    await clearDriveAssets()
}

async function hydrateStoredSettings(): Promise<void> {
    for (const { store } of stores) await store.persist?.rehydrate()
    // This build remains on-device regardless of a preference saved by another app version.
    useAppModeStore.getState().setAppMode('local')
    mmkv.set(AppSettings.SaveLocalKV, false)
    mmkv.set(AppSettings.PrintContext, false)
    mmkv.set(AppSettings.ShowNotificationText, false)
    const userId = Characters.useUserStore.getState().id
    if (userId !== undefined) await Characters.useUserStore.getState().setCard(userId)
}

async function lostDrive(): Promise<void> {
    await serial(async () => {
        await clearPrivateSession()
        await initializeDefaultData()
    })
}
onDriveUnavailable(lostDrive)

/** Startup restoration never writes bootstrap/default data over an existing USB snapshot. */
export async function restoreConnectedDriveSession(): Promise<void> {
    pauseDriveDatabaseSync()
    const folder = driveMemory.getState().folderUri
    if (!folder) {
        // Cache files can survive a killed process. Clear any previous session's
        // disposable portraits/attachments even if its picker grant was removed.
        await clearPrivateSession()
        await initializeDefaultData()
        return
    }
    try {
        await driveMemory.ensureReady()
        const value = await driveMemory.getApplicationState()
        if (driveMemory.getState().folderUri !== folder)
            throw new DriveMemoryError('The selected memory drive changed.')
        await clearPrivateSession()
        if (value !== undefined) {
            await restoreDriveApplicationState(value)
            await hydrateStoredSettings()
        } else {
            await initializeDefaultData()
            const config = Llama.useLlamaPreferencesStore.getState().config
            Llama.useLlamaPreferencesStore
                .getState()
                .setConfiguration({ ...config, context_length: 2048, threads: 4 })
        }
        if (driveMemory.getState().folderUri !== folder)
            throw new DriveMemoryError('The selected memory drive changed.')
        await seedDriveConversationCache()
        activateDriveDatabaseSync()
        await syncDriveDatabase()
    } catch (error) {
        driveMemory.invalidate(error)
        await clearPrivateSession()
        await initializeDefaultData()
        throw error
    }
}

export function connectDrive(): Promise<void> {
    return serial(async () => {
        await stopGeneration()
        if (isDriveSessionReady()) await syncDriveDatabase()
        await clearPrivateSession()
        try {
            const selected = await driveMemory.selectFolder()
            if (selected || driveMemory.getState().folderUri) await restoreConnectedDriveSession()
            else await initializeDefaultData()
        } catch (error) {
            await clearPrivateSession()
            await initializeDefaultData()
            throw error
        }
    })
}

export function disconnectDrive(): Promise<void> {
    return serial(async () => {
        let failure: unknown
        try {
            await stopGeneration()
            if (isDriveSessionReady()) await syncDriveDatabase()
            await driveMemory.flush()
            if (driveMemory.getState().folderUri) await driveMemory.ensureReady()
        } catch (error) {
            failure = error
        }
        // Keep the grant on a failed save/verification so the same USB can be
        // reconnected and recovered. The unavailable handler still clears RAM.
        if (failure) throw failure
        await clearPrivateSession()
        await driveMemory.disconnect()
        await initializeDefaultData()
    })
}

/** Restored SQL state is authoritative; archive previews are never executed as instructions. */
export async function continueDriveConversation(id: string): Promise<string | null> {
    const current = getDriveSessionGeneration()
    const check = () => {
        if (!isDriveSessionReady() || getDriveSessionGeneration() !== current) {
            throw new DriveMemoryError('The memory drive changed while opening the conversation.')
        }
    }
    await requireDriveSession()
    check()
    if (!/^\d+$/.test(id) || !Number.isSafeInteger(Number(id))) return null
    const chat = await Chats.db.query.chatShallow(Number(id))
    check()
    if (!chat) return null
    const character = await Characters.db.query.card(chat.character_id)
    check()
    if (!character)
        throw new DriveMemoryError('The saved conversation has no valid character profile.')
    let user
    if (chat.user_id !== null && chat.user_id !== undefined) {
        user = await Characters.db.query.card(chat.user_id)
        check()
    }
    const data = await Chats.db.query.chatNew(chat.id)
    check()
    // All async reads are complete before any view state is changed. A switch cannot
    // interleave between these synchronous assignments and leave an old profile visible.
    Characters.useCharacterStore.setState({
        id: chat.character_id,
        card: character,
        tokenCache: undefined,
    })
    if (user)
        Characters.useUserStore.setState({ id: chat.user_id!, card: user, tokenCache: undefined })
    Chats.useChatState.setState({
        id: chat.id,
        scrollData: {
            cause: 'saveScroll',
            index: Math.max(0, Math.min(data.scroll_offset, data.entriesCount - 1)),
        },
        buffer: { data: '' },
    })
    return String(chat.id)
}

export function removeDriveConversation(id: string): Promise<void> {
    const current = getDriveSessionGeneration()
    return serial(async () => {
        await requireDriveSession()
        if (getDriveSessionGeneration() !== current)
            throw new DriveMemoryError('The memory drive changed before deleting the conversation.')
        if (!/^\d+$/.test(id) || !Number.isSafeInteger(Number(id)))
            throw new DriveMemoryError('Invalid conversation ID.')
        await Chats.db.mutate.deleteChat(Number(id))
        if (getDriveSessionGeneration() !== current)
            throw new DriveMemoryError('The memory drive changed while deleting the conversation.')
        if (Chats.useChatState.getState().id === Number(id)) Chats.useChatState.getState().reset()
        await syncDriveDatabase()
        // Purge both recovery slots, including their authoritative application snapshots.
        await driveMemory.removeConversation(id)
    })
}

const tools: DriveToolStorage = {
    remember: async (text) => {
        await requireDriveSession()
        return driveMemory.saveManualEntry({
            kind: /^I prefer\b/i.test(text) ? 'preference' : 'fact',
            text,
        })
    },
    listMemories: async () => {
        await requireDriveSession()
        return driveMemory.getState().entries.filter((entry) => entry.kind !== 'note')
    },
    forgetMemory: async (id) => {
        await requireDriveSession()
        if (
            !driveMemory
                .getState()
                .entries.some((entry) => entry.id === id && entry.kind !== 'note')
        )
            return false
        await driveMemory.removeEntry(id)
        return true
    },
    saveNote: async (title, text) => {
        await requireDriveSession()
        const entry = await driveMemory.saveManualEntry({ kind: 'note', title, text })
        return { ...entry, title: entry.title ?? title }
    },
    listNotes: async () => {
        await requireDriveSession()
        return driveMemory
            .getState()
            .entries.filter((entry) => entry.kind === 'note')
            .map((entry) => ({ ...entry, title: entry.title ?? 'Note' }))
    },
    readNote: async (id) => {
        await requireDriveSession()
        const entry = driveMemory
            .getState()
            .entries.find((item) => item.id === id && item.kind === 'note')
        return entry ? { ...entry, title: entry.title ?? 'Note' } : undefined
    },
    updateNote: async (id, text) => {
        await requireDriveSession()
        const existing = driveMemory
            .getState()
            .entries.find((item) => item.id === id && item.kind === 'note')
        if (!existing) return undefined
        const entry = await driveMemory.updateEntry(id, { text, title: existing.title })
        return { ...entry, title: entry.title ?? 'Note' }
    },
    deleteNote: async (id) => {
        await requireDriveSession()
        if (
            !driveMemory
                .getState()
                .entries.some((entry) => entry.id === id && entry.kind === 'note')
        )
            return false
        await driveMemory.removeEntry(id)
        return true
    },
}

export async function executeDriveCommand(input: string): Promise<string | null> {
    const current = getDriveSessionGeneration()
    return serial(async () => {
        if (getDriveSessionGeneration() !== current)
            throw new DriveMemoryError('The memory drive changed before running the tool.')
        const guarded = Object.fromEntries(
            Object.entries(tools).map(([name, operation]) => [
                name,
                async (...args: unknown[]) => {
                    if (getDriveSessionGeneration() !== current)
                        throw new DriveMemoryError(
                            'The memory drive changed while running the tool.'
                        )
                    const result = await (
                        operation as (...parameters: unknown[]) => Promise<unknown>
                    )(...args)
                    if (getDriveSessionGeneration() !== current)
                        throw new DriveMemoryError(
                            'The memory drive changed while running the tool.'
                        )
                    return result
                },
            ])
        ) as unknown as DriveToolStorage
        const result = await dispatchDriveCommand(input, guarded)
        if (getDriveSessionGeneration() !== current)
            throw new DriveMemoryError('The memory drive changed while running the tool.')
        return result?.text ?? null
    })
}
