import { dispatchDriveCommand, DriveMemoryItem, DriveNote, DriveToolStorage } from '../index'

/** Re-opening the adapter preserves the same underlying drive contents. */
function createAdapter(drive: {
    memories: DriveMemoryItem[]
    notes: DriveNote[]
}): DriveToolStorage {
    return {
        remember: jest.fn(async (text) => {
            const item = { id: `memory-${drive.memories.length + 1}`, text }
            drive.memories.push(item)
            return item
        }),
        listMemories: jest.fn(async () => drive.memories),
        forgetMemory: jest.fn(async (id) => {
            const index = drive.memories.findIndex((item) => item.id === id)
            if (index === -1) return false
            drive.memories.splice(index, 1)
            return true
        }),
        saveNote: jest.fn(async (title, text) => {
            const item = { id: `note-${drive.notes.length + 1}`, title, text }
            drive.notes.push(item)
            return item
        }),
        listNotes: jest.fn(async () => drive.notes),
        readNote: jest.fn(async (id) => drive.notes.find((item) => item.id === id)),
        updateNote: jest.fn(async (id, text) => {
            const item = drive.notes.find((item) => item.id === id)
            if (item) item.text = text
            return item
        }),
        deleteNote: jest.fn(async (id) => {
            const index = drive.notes.findIndex((item) => item.id === id)
            if (index === -1) return false
            drive.notes.splice(index, 1)
            return true
        }),
    }
}

describe('explicit offline toolkit commands', () => {
    let drive: { memories: DriveMemoryItem[]; notes: DriveNote[] }
    let storage: DriveToolStorage
    beforeEach(() => {
        drive = { memories: [], notes: [] }
        storage = createAdapter(drive)
    })

    test('normal chat remains normal chat; unknown commands are not dispatched', async () => {
        expect(await dispatchDriveCommand('Please remember that I like tea.', storage)).toBeNull()
        expect(await dispatchDriveCommand('/shell rm -rf /', storage)).toMatchObject({ ok: false })
        expect(await dispatchDriveCommand('/web https://example.com', storage)).toMatchObject({
            ok: false,
        })
        expect(await dispatchDriveCommand('/calc;process.exit()', storage)).toMatchObject({
            ok: false,
        })
        expect(storage.remember).not.toHaveBeenCalled()
        expect(storage.listNotes).not.toHaveBeenCalled()
    })

    test('calculator and help need no attached drive or model', async () => {
        const unavailable = Object.fromEntries(
            Object.keys(storage).map((key) => [
                key,
                jest.fn(() => {
                    throw new Error('USB detached')
                }),
            ])
        ) as unknown as DriveToolStorage
        expect(await dispatchDriveCommand('/calc (12 + 8) * 3', unavailable)).toEqual({
            command: 'calc',
            ok: true,
            text: '(12 + 8) * 3 = 60',
        })
        expect(await dispatchDriveCommand('/help', unavailable)).toMatchObject({ ok: true })
        expect(await dispatchDriveCommand('/calc 1/0', unavailable)).toMatchObject({
            ok: false,
            text: 'Calculator: Cannot divide by zero.',
        })
        for (const method of Object.values(unavailable)) expect(method).not.toHaveBeenCalled()
    })

    test('explicit memories persist across a new adapter and can be forgotten', async () => {
        expect(
            await dispatchDriveCommand('/remember I prefer brief answers', storage)
        ).toMatchObject({
            ok: true,
            text: 'Remembered [memory-1]: I prefer brief answers',
        })
        const reopened = createAdapter(drive)
        expect(await dispatchDriveCommand('/memories', reopened)).toMatchObject({
            ok: true,
            text: '[memory-1] I prefer brief answers',
        })
        expect(await dispatchDriveCommand('/forget memory-1', reopened)).toMatchObject({ ok: true })
        expect(drive.memories).toHaveLength(0)
        expect(await dispatchDriveCommand('/forget memory-1', reopened)).toMatchObject({
            ok: false,
        })
    })

    test('notes preserve multiline content, can be reopened, updated, and deleted', async () => {
        expect(
            await dispatchDriveCommand('/note Shopping | Milk\nBread | Apples', storage)
        ).toMatchObject({ ok: true })
        const reopened = createAdapter(drive)
        expect(await dispatchDriveCommand('/notes', reopened)).toMatchObject({
            text: '[note-1] Shopping',
        })
        expect(await dispatchDriveCommand('/read-note note-1', reopened)).toMatchObject({
            text: 'Shopping [note-1]\n\nMilk\nBread | Apples',
        })
        expect(
            await dispatchDriveCommand('/edit-note note-1 | Eggs\nCheese', reopened)
        ).toMatchObject({
            ok: true,
            text: 'Updated note [note-1]: Shopping',
        })
        expect(await dispatchDriveCommand('/read-note note-1', createAdapter(drive))).toMatchObject(
            {
                text: 'Shopping [note-1]\n\nEggs\nCheese',
            }
        )
        expect(
            await dispatchDriveCommand('/edit-note missing-id | Replacement', reopened)
        ).toMatchObject({ ok: false })
        expect(await dispatchDriveCommand('/delete-note note-1', reopened)).toMatchObject({
            ok: true,
        })
        expect(drive.notes).toHaveLength(0)
        expect(await dispatchDriveCommand('/read-note note-1', reopened)).toMatchObject({
            ok: false,
        })
    })

    test.each([
        '/remember',
        '/remember ' + 'x'.repeat(2001),
        '/forget',
        '/forget one two',
        '/note Title',
        '/note | text',
        '/note Title |',
        '/note ' + 'x'.repeat(121) + ' | text',
        '/note Title | ' + 'x'.repeat(2001),
        '/notes extra',
        '/memories extra',
        '/help extra',
        '/read-note ../../file',
        '/delete-note note-1 other',
        '/edit-note note-1',
        '/edit-note | Replacement',
        '/edit-note note-1 |',
        '/edit-note note-1 | ' + 'x'.repeat(2001),
    ])('invalid input makes no storage change: %s', async (input) => {
        expect(await dispatchDriveCommand(input, storage)).toMatchObject({ ok: false })
        expect(drive).toEqual({ memories: [], notes: [] })
        expect(storage.remember).not.toHaveBeenCalled()
        expect(storage.saveNote).not.toHaveBeenCalled()
        expect(storage.forgetMemory).not.toHaveBeenCalled()
        expect(storage.deleteNote).not.toHaveBeenCalled()
        expect(storage.updateNote).not.toHaveBeenCalled()
    })

    test('USB/storage failures are shown and never claimed to be saved', async () => {
        storage.remember = jest.fn(async () => {
            throw new Error('Connect the memory drive before saving.')
        })
        expect(await dispatchDriveCommand('/remember My favorite color is blue', storage)).toEqual({
            command: 'remember',
            ok: false,
            text: 'Connect the memory drive before saving.',
        })
        expect(drive.memories).toHaveLength(0)
    })
})
