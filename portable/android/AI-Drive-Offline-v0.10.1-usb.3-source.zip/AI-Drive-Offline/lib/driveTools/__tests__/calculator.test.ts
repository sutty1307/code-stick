import { calculate, CalculationError, formatCalculation } from '../calculator'

describe('bounded offline arithmetic', () => {
    test.each([
        ['2 + 3 * 4', 14],
        ['(2 + 3) * 4', 20],
        ['10 / 2 - 1', 4],
        ['2^3^2', 512],
        ['-2^2', -4],
        ['(-2)^2', 4],
        ['2^-3', 0.125],
        ['5 % 3', 2],
        ['.5 + 2.5e-1', 0.75],
        [' 3. + +2 ', 5],
        ['3--2', 5],
    ])('%s = %s', (expression, expected) => {
        expect(calculate(expression as string)).toBe(expected)
    })

    test.each([
        '1 / 0',
        '1 / -0',
        '2 % 0',
        '1e309',
        '1e308 * 2',
        '(-1)^0.5',
        '2 +',
        '(2 + 3',
        '2 + 3)',
        '2(3)',
        '1 2',
        '()',
        '',
        '1..2',
        '2 ** 3',
        'Math.random()',
        'process.exit()',
        'globalThis.secret',
        '1; alert(1)',
        'constructor.constructor("return process")()',
        'fetch("https://example.com")',
        '`shell`',
        '0x10',
        'Infinity',
        '1'.repeat(513),
        '('.repeat(34) + '1' + ')'.repeat(34),
        '-'.repeat(34) + '1',
        '1+'.repeat(128) + '1',
    ])('rejects invalid, dangerous, or excessive expression: %s', (expression) => {
        expect(() => calculate(expression)).toThrow(CalculationError)
    })

    test('explains division and remainder by zero', () => {
        expect(() => calculate('1/0')).toThrow('Cannot divide by zero.')
        expect(() => calculate('1%0')).toThrow('Cannot take a remainder with zero.')
    })

    test('formats decimal display noise and normalizes negative zero', () => {
        expect(formatCalculation(calculate('0.1+0.2'))).toBe('0.3')
        expect(calculate('-0')).toBe(0)
        expect(Object.is(calculate('-0'), -0)).toBe(false)
    })
})
