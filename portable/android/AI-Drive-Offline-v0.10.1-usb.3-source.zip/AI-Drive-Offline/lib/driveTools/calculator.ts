/** A bounded arithmetic parser. Expressions never become executable JavaScript. */
export class CalculationError extends Error {
    constructor(message: string) {
        super(message)
        this.name = 'CalculationError'
    }
}

type Token = { type: 'number'; value: number } | { type: 'symbol'; value: string }
const MAX_EXPRESSION_LENGTH = 512
const MAX_TOKENS = 256
const MAX_DEPTH = 32

function tokenize(expression: string): Token[] {
    if (!expression.trim())
        throw new CalculationError('Enter an expression, for example /calc (12 + 8) * 3.')
    if (expression.length > MAX_EXPRESSION_LENGTH)
        throw new CalculationError('The expression is too long. Use 512 characters or fewer.')

    const tokens: Token[] = []
    let position = 0
    while (position < expression.length) {
        const char = expression[position]
        if (/\s/.test(char)) {
            position++
            continue
        }
        const number = /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?/.exec(expression.slice(position))
        if (number) {
            const value = Number(number[0])
            if (!Number.isFinite(value)) throw new CalculationError('A number is too large.')
            tokens.push({ type: 'number', value })
            position += number[0].length
        } else if ('+-*/%^()'.includes(char)) {
            tokens.push({ type: 'symbol', value: char })
            position++
        } else {
            throw new CalculationError('Use only numbers, parentheses, and + - * / % ^.')
        }
        if (tokens.length > MAX_TOKENS)
            throw new CalculationError('The expression has too many parts.')
    }
    return tokens
}

function finite(value: number): number {
    if (!Number.isFinite(value))
        throw new CalculationError('The calculation does not have a finite real result.')
    return value
}

export function calculate(expression: string): number {
    const tokens = tokenize(expression)
    let position = 0

    function match(symbol: string): boolean {
        const token = tokens[position]
        if (token?.type !== 'symbol' || token.value !== symbol) return false
        position++
        return true
    }

    function checkDepth(depth: number): void {
        if (depth > MAX_DEPTH)
            throw new CalculationError('There are too many nested parentheses or operators.')
    }

    function sum(depth: number): number {
        let value = product(depth)
        while (true) {
            if (match('+')) value = finite(value + product(depth))
            else if (match('-')) value = finite(value - product(depth))
            else return value
        }
    }

    function product(depth: number): number {
        let value = unary(depth)
        while (true) {
            if (match('*')) value = finite(value * unary(depth))
            else if (match('/')) {
                const divisor = unary(depth)
                if (divisor === 0) throw new CalculationError('Cannot divide by zero.')
                value = finite(value / divisor)
            } else if (match('%')) {
                const divisor = unary(depth)
                if (divisor === 0) throw new CalculationError('Cannot take a remainder with zero.')
                value = finite(value % divisor)
            } else return value
        }
    }

    function unary(depth: number): number {
        checkDepth(depth)
        if (match('+')) return unary(depth + 1)
        if (match('-')) return -unary(depth + 1)
        return power(depth)
    }

    function power(depth: number): number {
        let value = primary(depth)
        // A unary exponent allows 2^-3; recursive parsing makes 2^3^2 equal 2^(3^2).
        if (match('^')) value = finite(Math.pow(value, unary(depth + 1)))
        return value
    }

    function primary(depth: number): number {
        checkDepth(depth)
        if (match('(')) {
            const value = sum(depth + 1)
            if (!match(')')) throw new CalculationError('A closing parenthesis is missing.')
            return value
        }
        const token = tokens[position]
        if (token?.type === 'number') {
            position++
            return token.value
        }
        throw new CalculationError('Expected a number or an opening parenthesis.')
    }

    const result = finite(sum(0))
    if (position !== tokens.length)
        throw new CalculationError(
            'Unexpected input. Put an operator between numbers and check the parentheses.'
        )
    return Object.is(result, -0) ? 0 : result
}

/** Hide insignificant floating-point display noise without claiming exact decimal arithmetic. */
export function formatCalculation(value: number): string {
    return String(Number(finite(value).toPrecision(15)))
}
