import { calculate, CalculationError, formatCalculation } from './calculator'

export interface DriveMemoryItem {
    id: string
    text: string
}

export interface DriveNote extends DriveMemoryItem {
    title: string
}

/** All storage comes from the caller's USB-backed adapter; tools do not access a network. */
export interface DriveToolStorage {
    remember(text: string): Promise<DriveMemoryItem>
    listMemories(): Promise<DriveMemoryItem[]>
    forgetMemory(id: string): Promise<boolean>
    saveNote(title: string, text: string): Promise<DriveNote>
    listNotes(): Promise<DriveNote[]>
    readNote(id: string): Promise<DriveNote | undefined>
    updateNote(id: string, text: string): Promise<DriveNote | undefined>
    deleteNote(id: string): Promise<boolean>
}

export interface DriveCommandResult {
    command: string
    ok: boolean
    text: string
}

export const DRIVE_TOOL_HELP = [
    'Offline tools (type a command in the chat):',
    '/calc (12 + 8) * 3 — calculate with + - * / % ^ and parentheses',
    '/remember I prefer brief answers — save a fact or preference',
    '/memories — list saved facts and preferences with their IDs',
    '/forget ID — delete one saved fact or preference',
    '/note Shopping | Milk, bread, apples — save a named note',
    '/notes — list note titles and their IDs',
    '/read-note ID — show a saved note',
    "/edit-note ID | TEXT — replace a note's text, keeping its title",
    '/delete-note ID — delete one note',
    '/help — show these commands',
    'These tools run locally. Notes and memories use the connected memory drive.',
].join('\n')

const TEXT_LIMIT = 2000
const TITLE_LIMIT = 120
const LIST_LIMIT = 100

function itemId(argument: string): string {
    const id = argument.trim()
    if (!/^[A-Za-z0-9._:-]{1,160}$/.test(id))
        throw new Error('Use the ID shown by /memories or /notes, for example /forget memory-123.')
    return id
}

function requiredText(argument: string, example: string): string {
    const text = argument.trim()
    if (!text) throw new Error(example)
    if (text.length > TEXT_LIMIT) throw new Error(`Use ${TEXT_LIMIT} characters or fewer.`)
    return text
}

function noArgument(argument: string, command: string): void {
    if (argument.trim()) throw new Error(`Use /${command} by itself.`)
}

function listing<T>(items: T[], render: (item: T) => string, empty: string): string {
    if (!items.length) return empty
    const lines = items.slice(0, LIST_LIMIT).map(render)
    if (items.length > LIST_LIMIT)
        lines.push(`Showing the first ${LIST_LIMIT} of ${items.length} entries.`)
    return lines.join('\n\n')
}

/**
 * Only explicit commands typed by the person are dispatched. Model output is not a tool call.
 * Returns null for regular chat text. Unsupported slash commands return a visible error.
 */
export async function dispatchDriveCommand(
    input: string,
    storage: DriveToolStorage
): Promise<DriveCommandResult | null> {
    const trimmed = input.trim()
    if (!trimmed.startsWith('/')) return null
    const match = /^\/([a-z][a-z-]*)(?:\s+([\s\S]*))?$/i.exec(trimmed)
    if (!match)
        return {
            command: '',
            ok: false,
            text: 'Unknown command. Type /help to see the offline tools.',
        }
    const command = match[1].toLowerCase()
    const argument = match[2] ?? ''
    const success = (text: string): DriveCommandResult => ({ command, ok: true, text })

    try {
        switch (command) {
            case 'help':
                noArgument(argument, command)
                return success(DRIVE_TOOL_HELP)
            case 'calc':
                return success(`${argument.trim()} = ${formatCalculation(calculate(argument))}`)
            case 'remember': {
                const text = requiredText(
                    argument,
                    'Use /remember followed by the fact or preference to save.'
                )
                const saved = await storage.remember(text)
                return success(`Remembered [${saved.id}]: ${saved.text}`)
            }
            case 'memories': {
                noArgument(argument, command)
                const items = await storage.listMemories()
                return success(
                    listing(
                        items,
                        (item) => `[${item.id}] ${item.text}`,
                        'No saved facts or preferences yet. Use /remember to add one.'
                    )
                )
            }
            case 'forget': {
                const id = itemId(argument)
                const removed = await storage.forgetMemory(id)
                return removed
                    ? success(`Forgot memory [${id}].`)
                    : {
                          command,
                          ok: false,
                          text: `No saved memory has ID [${id}]. Use /memories to see the IDs.`,
                      }
            }
            case 'note': {
                const separator = argument.indexOf('|')
                if (separator === -1)
                    throw new Error(
                        'Use /note TITLE | TEXT, for example /note Shopping | Milk and bread.'
                    )
                const title = argument.slice(0, separator).trim()
                if (!title || title.length > TITLE_LIMIT)
                    throw new Error(`Give the note a title of 1–${TITLE_LIMIT} characters.`)
                const text = requiredText(
                    argument.slice(separator + 1),
                    'Add the note text after the | character.'
                )
                const note = await storage.saveNote(title, text)
                return success(`Saved note [${note.id}]: ${note.title}`)
            }
            case 'notes': {
                noArgument(argument, command)
                const notes = await storage.listNotes()
                return success(
                    listing(
                        notes,
                        (note) => `[${note.id}] ${note.title}`,
                        'No notes yet. Use /note TITLE | TEXT to save one.'
                    )
                )
            }
            case 'read-note': {
                const id = itemId(argument)
                const note = await storage.readNote(id)
                return note
                    ? success(`${note.title} [${note.id}]\n\n${note.text}`)
                    : {
                          command,
                          ok: false,
                          text: `No note has ID [${id}]. Use /notes to see the IDs.`,
                      }
            }
            case 'edit-note': {
                const separator = argument.indexOf('|')
                if (separator === -1)
                    throw new Error("Use /edit-note ID | TEXT to replace a note's text.")
                const id = itemId(argument.slice(0, separator))
                const text = requiredText(
                    argument.slice(separator + 1),
                    'Add the replacement note text after the | character.'
                )
                const note = await storage.updateNote(id, text)
                return note
                    ? success(`Updated note [${note.id}]: ${note.title}`)
                    : {
                          command,
                          ok: false,
                          text: `No note has ID [${id}]. Use /notes to see the IDs.`,
                      }
            }
            case 'delete-note': {
                const id = itemId(argument)
                const removed = await storage.deleteNote(id)
                return removed
                    ? success(`Deleted note [${id}].`)
                    : {
                          command,
                          ok: false,
                          text: `No note has ID [${id}]. Use /notes to see the IDs.`,
                      }
            }
            default:
                return {
                    command,
                    ok: false,
                    text: `Unknown command /${command}. Type /help to see the offline tools.`,
                }
        }
    } catch (error) {
        const reason =
            error instanceof Error ? error.message : 'The tool could not complete the request.'
        return {
            command,
            ok: false,
            text: error instanceof CalculationError ? `Calculator: ${reason}` : reason,
        }
    }
}
