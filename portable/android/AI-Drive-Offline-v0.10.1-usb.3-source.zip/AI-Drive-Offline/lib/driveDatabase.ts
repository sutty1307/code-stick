import { is } from 'drizzle-orm'
import { getTableConfig, SQLiteTable } from 'drizzle-orm/sqlite-core'
import { Directory, File } from 'expo-file-system'
import { addDatabaseChangeListener } from 'expo-sqlite'

import { sqliteDB } from '@db/db'
import * as schema from '@db/schema'
import { Storage } from '@lib/enums/Storage'
import { mmkv } from '@lib/storage/MMKV'
import { AppDirectory } from '@lib/utils/File'

import { captureCandidate, driveMemory, DriveMemoryError } from './driveMemory'

type Cell = string | number | null
type Row = Record<string, Cell>
type TableDefinition = { name: string; columns: string[] }
type TableSnapshot = TableDefinition & { rows: Row[] }
type Settings = Record<string, string | number | boolean>
type Asset = { area: 'characters' | 'assets' | 'attachments'; name: string; base64: string }

export type DriveApplicationSnapshot = {
    format: 'chatterui-drive-application-v1'
    tables: TableSnapshot[]
    preferences: Settings
    assets: Asset[]
    // Optional for compatibility with snapshots created before counter preservation.
    sequences?: Record<string, number>
}

// The allowlist comes from the bundled app, never from a drive file or SQLite's schema table.
const tableConfigurations = Object.values(schema)
    .filter((table) => is(table, SQLiteTable))
    .map((table) => getTableConfig(table as SQLiteTable))
const definitions: TableDefinition[] = tableConfigurations
    .map((config) => ({ name: config.name, columns: config.columns.map((column) => column.name) }))
    .sort((a, b) => a.name.localeCompare(b.name))
const allowedTables = new Set(definitions.map((table) => table.name))
const autoIncrementColumns = new Map(
    tableConfigurations.flatMap((config) =>
        config.columns
            .filter((column) => 'autoIncrement' in column && column.autoIncrement === true)
            .map((column) => [config.name, column.name] as const)
    )
)
const assetDirectories = () => ({
    characters: AppDirectory.CharacterPath,
    assets: AppDirectory.Assets,
    attachments: AppDirectory.Attachments,
})
const quote = (name: string) => `"${name.replace(/"/g, '""')}"`
const record = (value: unknown): value is Record<string, unknown> =>
    !!value && typeof value === 'object' && !Array.isArray(value)
const validName = (name: string) =>
    name.length > 0 &&
    name.length <= 180 &&
    name !== '.' &&
    name !== '..' &&
    !/[\\/\u0000-\u001f\u007f]/.test(name)
class DatabaseBusyError extends DriveMemoryError {}
function transaction(task: () => void): void {
    if (sqliteDB.isInTransactionSync())
        throw new DatabaseBusyError('A chat update is still finishing. Retry the USB operation.')
    // BEGIN sits outside the rollback handler: a failed BEGIN must never roll back
    // another caller's still-running asynchronous transaction on this connection.
    sqliteDB.execSync('BEGIN')
    try {
        task()
        sqliteDB.execSync('COMMIT')
    } catch (error) {
        sqliteDB.execSync('ROLLBACK')
        throw error
    }
}

/** Reject an entire malformed snapshot before any existing application data is changed. */
export function validateDriveApplicationSnapshot(value: unknown): DriveApplicationSnapshot {
    if (
        !record(value) ||
        value.format !== 'chatterui-drive-application-v1' ||
        !Array.isArray(value.tables) ||
        value.tables.length !== definitions.length ||
        !record(value.preferences) ||
        !Array.isArray(value.assets)
    ) {
        throw new DriveMemoryError(
            'The USB application snapshot is incompatible. Its files were not overwritten.'
        )
    }
    if (
        value.sequences !== undefined &&
        (!record(value.sequences) ||
            Object.entries(value.sequences).some(
                ([name, counter]) =>
                    !autoIncrementColumns.has(name) ||
                    typeof counter !== 'number' ||
                    !Number.isSafeInteger(counter) ||
                    counter < 0
            ))
    ) {
        throw new DriveMemoryError(
            'The USB snapshot contains invalid ID counters. Its files were not overwritten.'
        )
    }
    const byName = new Map<string, unknown>()
    for (const table of value.tables) {
        if (
            !record(table) ||
            typeof table.name !== 'string' ||
            !allowedTables.has(table.name) ||
            byName.has(table.name)
        )
            throw new DriveMemoryError('The USB snapshot contains an unknown or duplicate table.')
        byName.set(table.name, table)
    }
    for (const definition of definitions) {
        const table = byName.get(definition.name)
        if (
            !record(table) ||
            !Array.isArray(table.columns) ||
            !Array.isArray(table.rows) ||
            JSON.stringify(table.columns) !== JSON.stringify(definition.columns)
        ) {
            throw new DriveMemoryError(
                `The USB snapshot has incompatible columns for ${definition.name}.`
            )
        }
        for (const row of table.rows) {
            if (
                !record(row) ||
                Object.keys(row).length !== definition.columns.length ||
                definition.columns.some(
                    (column) => !Object.prototype.hasOwnProperty.call(row, column)
                ) ||
                Object.values(row).some(
                    (cell) =>
                        cell !== null &&
                        typeof cell !== 'string' &&
                        !(typeof cell === 'number' && Number.isFinite(cell))
                )
            ) {
                throw new DriveMemoryError(
                    `The USB snapshot contains an invalid ${definition.name} record.`
                )
            }
        }
    }
    for (const [key, setting] of Object.entries(value.preferences)) {
        if (
            !key ||
            key.length > 200 ||
            /[\u0000-\u001f]/.test(key) ||
            !['string', 'number', 'boolean'].includes(typeof setting) ||
            (typeof setting === 'number' && !Number.isFinite(setting))
        ) {
            throw new DriveMemoryError('The USB snapshot contains invalid settings.')
        }
    }
    const assetKeys = new Set<string>()
    for (const asset of value.assets) {
        if (
            !record(asset) ||
            typeof asset.area !== 'string' ||
            !['characters', 'assets', 'attachments'].includes(asset.area) ||
            typeof asset.name !== 'string' ||
            !validName(asset.name) ||
            typeof asset.base64 !== 'string' ||
            !/^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(
                asset.base64
            ) ||
            assetKeys.has(`${asset.area}/${asset.name}`)
        ) {
            throw new DriveMemoryError(
                'The USB snapshot contains an invalid attachment or portrait.'
            )
        }
        assetKeys.add(`${asset.area}/${asset.name}`)
    }
    const attachments = byName.get('chat_attachment') as TableSnapshot | undefined
    for (const row of attachments?.rows ?? []) {
        if (typeof row.uri !== 'string')
            throw new DriveMemoryError('The USB snapshot contains an invalid attachment reference.')
        const name = row.uri.split('/').pop()!
        if (!validName(name) || !assetKeys.has(`attachments/${name}`)) {
            throw new DriveMemoryError(
                'An attachment is missing from the USB snapshot. Its files were not overwritten.'
            )
        }
    }
    return value as DriveApplicationSnapshot
}

export async function captureDriveApplicationState(): Promise<DriveApplicationSnapshot> {
    let tables: TableSnapshot[] = []
    let sequences: Record<string, number> = {}
    // Synchronous work uses the one RAM connection. An exclusive async connection would
    // create a different ':memory:' database, and unrelated async writes could interleave.
    transaction(() => {
        tables = definitions.map((definition) => ({
            ...definition,
            rows: sqliteDB.getAllSync<Row>(`SELECT * FROM ${quote(definition.name)}`),
        }))
        const counters = sqliteDB.getAllSync<{ name: string; seq: number }>(
            'SELECT name, seq FROM sqlite_sequence'
        )
        sequences = Object.fromEntries(
            [...autoIncrementColumns.keys()].map((name) => [
                name,
                counters.find((counter) => counter.name === name)?.seq ?? 0,
            ])
        )
    })
    const preferences = { ...mmkv.snapshot() }
    delete preferences[Storage.Logs] // Logging a successful save must not trigger another save.
    const assets: Asset[] = []
    for (const [area, uri] of Object.entries(assetDirectories())) {
        const directory = new Directory(uri)
        if (!directory.exists) continue
        for (const file of directory.list()) {
            if (
                !(file instanceof File) ||
                (area === 'assets' && file.name === 'llama3tokenizer.gguf')
            )
                continue
            if (!validName(file.name))
                throw new DriveMemoryError('An attachment has an unsupported filename.')
            assets.push({
                area: area as Asset['area'],
                name: file.name,
                base64: await file.base64(),
            })
        }
    }
    return validateDriveApplicationSnapshot({
        format: 'chatterui-drive-application-v1',
        tables,
        preferences,
        assets,
        sequences,
    })
}

export async function clearDriveAssets(): Promise<void> {
    for (const uri of Object.values(assetDirectories())) {
        const directory = new Directory(uri)
        if (directory.exists) directory.delete()
        directory.create({ idempotent: true, intermediates: true })
    }
}

export function clearDriveDatabase(): void {
    transaction(() => {
        sqliteDB.execSync('PRAGMA defer_foreign_keys = ON')
        for (const definition of [...definitions].reverse()) {
            sqliteDB.runSync(`DELETE FROM ${quote(definition.name)}`)
        }
        for (const name of autoIncrementColumns.keys()) {
            sqliteDB.runSync('DELETE FROM sqlite_sequence WHERE name = ?', [name])
        }
    })
}

export async function restoreDriveApplicationState(
    value: unknown
): Promise<DriveApplicationSnapshot> {
    const snapshot = validateDriveApplicationSnapshot(value)
    // Stage only validated basenames inside the app's cache directories. Never follow a
    // path, SQL statement, or content URI from the drive snapshot when writing local files.
    await clearDriveAssets()
    for (const asset of snapshot.assets) {
        new File(assetDirectories()[asset.area], asset.name).write(asset.base64, {
            encoding: 'base64',
        })
    }
    const restoredTables = new Map(snapshot.tables.map((table) => [table.name, table]))
    const attachmentBase = assetDirectories().attachments
    transaction(() => {
        sqliteDB.execSync('PRAGMA defer_foreign_keys = ON')
        for (const definition of [...definitions].reverse())
            sqliteDB.runSync(`DELETE FROM ${quote(definition.name)}`)
        for (const name of autoIncrementColumns.keys()) {
            sqliteDB.runSync('DELETE FROM sqlite_sequence WHERE name = ?', [name])
        }
        for (const definition of definitions) {
            const table = restoredTables.get(definition.name)!
            const sql = `INSERT INTO ${quote(definition.name)} (${definition.columns.map(quote).join(',')}) VALUES (${definition.columns.map(() => '?').join(',')})`
            for (const row of table.rows) {
                const restored = { ...row }
                if (definition.name === 'chat_attachment' && typeof restored.uri === 'string') {
                    const name = restored.uri.split('/').pop()!
                    if (
                        !validName(name) ||
                        !snapshot.assets.some(
                            (asset) => asset.area === 'attachments' && asset.name === name
                        )
                    ) {
                        throw new DriveMemoryError(
                            'An attachment is missing from the USB snapshot.'
                        )
                    }
                    restored.uri = attachmentBase + name
                }
                sqliteDB.runSync(
                    sql,
                    definition.columns.map((column) => restored[column])
                )
            }
        }
        for (const [name, column] of autoIncrementColumns) {
            const maximum =
                sqliteDB.getAllSync<{ maximum: number | null }>(
                    `SELECT MAX(${quote(column)}) AS maximum FROM ${quote(name)}`
                )[0]?.maximum ?? 0
            const counter = Math.max(0, maximum, snapshot.sequences?.[name] ?? 0)
            if (!Number.isSafeInteger(counter))
                throw new DriveMemoryError('The USB snapshot has an unsafe ID counter.')
            // sqlite_sequence has no unique constraint on name. Replace using bound
            // values, preserving deleted IDs without inheriting another drive's counter.
            sqliteDB.runSync('DELETE FROM sqlite_sequence WHERE name = ?', [name])
            sqliteDB.runSync('INSERT INTO sqlite_sequence (name, seq) VALUES (?, ?)', [
                name,
                counter,
            ])
        }
    })
    mmkv.restore(snapshot.preferences)
    return snapshot
}

let initialized = false
let active = false
let generation = 0
let timer: ReturnType<typeof setTimeout> | undefined
let pending: Promise<void> | undefined
let dirty = false
let lastSnapshot = ''
let lostDriveHandler: (() => Promise<void>) | undefined
const archived = new Map<string, string>()
const captured = new Set<string>()
const sessionListeners = new Set<() => void>()
const publishSession = () => sessionListeners.forEach((listener) => listener())

export function isDriveSessionReady(): boolean {
    return active
}
export function getDriveSessionGeneration(): number {
    return generation
}
export function subscribeDriveSession(listener: () => void): () => void {
    sessionListeners.add(listener)
    return () => {
        sessionListeners.delete(listener)
    }
}
export async function waitForDriveDatabaseSync(): Promise<void> {
    await pending?.catch(() => undefined)
}
export function pauseDriveDatabaseSync(): void {
    active = false
    generation += 1
    dirty = false
    if (timer) clearTimeout(timer)
    timer = undefined
    lastSnapshot = ''
    archived.clear()
    captured.clear()
    publishSession()
}
export function activateDriveDatabaseSync(): void {
    active = true
    publishSession()
}
export function onDriveUnavailable(handler: () => Promise<void>): void {
    lostDriveHandler = handler
}
export async function seedDriveConversationCache(): Promise<void> {
    for (const previous of await driveMemory.listConversations()) {
        archived.set(
            previous.id,
            JSON.stringify({
                id: previous.id,
                title: previous.title,
                metadata: previous.metadata,
                messages: previous.messages,
            })
        )
    }
}

function changed(): void {
    if (!active) return
    dirty = true
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => {
        timer = undefined
        void syncDriveDatabase().catch(() => {
            /* Core exposes the failed USB status to the UI. */
        })
    }, 600)
}

function installListeners(): void {
    if (initialized) return
    initialized = true
    addDatabaseChangeListener((event) => {
        if (allowedTables.has(event.tableName)) changed()
    })
    mmkv.subscribe((key) => {
        if (key !== Storage.Logs) changed()
    })
    driveMemory.subscribe(() => {
        const status = driveMemory.getState().status
        if (active && !['ready', 'syncing'].includes(status)) {
            pauseDriveDatabaseSync()
            void lostDriveHandler?.().catch(() => {
                /* Keep a failed session disabled. */
            })
        }
    })
}

export async function requireDriveSession(): Promise<void> {
    if (!active)
        throw new DriveMemoryError('Connect your memory drive and wait for it to load first.')
    const current = generation
    await driveMemory.ensureReady()
    if (!active || generation !== current)
        throw new DriveMemoryError('The memory drive changed. Connect it again.')
}

function conversationSnapshots(snapshot: DriveApplicationSnapshot) {
    const rows = (name: string) => snapshot.tables.find((table) => table.name === name)?.rows ?? []
    const entries = rows('chat_entries')
    const swipes = rows('chat_swipes')
    return rows('chats').map((chat) => ({
        id: String(chat.id),
        title: String(chat.name),
        metadata: { characterId: chat.character_id, userId: chat.user_id },
        messages: entries
            .filter((entry) => entry.chat_id === chat.id)
            .sort((a, b) => Number(a.id) - Number(b.id))
            .flatMap((entry) => {
                const swipe = swipes.find((item) => item.entry_id === entry.id && item.active === 1)
                if (!swipe) return []
                return [
                    {
                        id: String(entry.id),
                        role: entry.is_user === 1 ? ('user' as const) : ('assistant' as const),
                        text: String(swipe.swipe),
                        createdAt: new Date(Number(swipe.send_date) * 1000).toISOString(),
                    },
                ]
            }),
    }))
}

async function saveCurrentState(current: number): Promise<void> {
    await requireDriveSession()
    const snapshot = await captureDriveApplicationState()
    if (!active || generation !== current)
        throw new DriveMemoryError('The memory drive changed while saving.')
    const serialized = JSON.stringify(snapshot)
    if (serialized === lastSnapshot) return
    // Save the complete application snapshot first; it is the restore authority, including
    // alternate replies, all settings, notes, and full message text without truncation.
    await driveMemory.setApplicationState(snapshot)
    if (!active || generation !== current) return
    lastSnapshot = serialized
    const conversations = conversationSnapshots(snapshot)
    const currentIds = new Set(conversations.map((conversation) => conversation.id))
    for (const previous of await driveMemory.listConversations()) {
        if (!active || generation !== current) return
        if (!currentIds.has(previous.id)) {
            await driveMemory.removeConversation(previous.id)
            archived.delete(previous.id)
        }
    }
    for (const conversation of conversations) {
        if (!active || generation !== current) return
        const value = JSON.stringify(conversation)
        if (archived.get(conversation.id) !== value) {
            await driveMemory.archiveConversation(conversation)
            if (!active || generation !== current) return
            archived.set(conversation.id, value)
        }
        for (const message of conversation.messages) {
            const key = `${conversation.id}:${message.id}`
            if (message.role !== 'user' || captured.has(key)) continue
            if (captureCandidate(message.text)) {
                await driveMemory.captureUserMessage(message.text, {
                    conversationId: conversation.id,
                    messageId: message.id,
                })
            }
            captured.add(key)
        }
    }
}

/** Explicit calls propagate a USB failure; debounced calls expose it through drive status. */
export async function syncDriveDatabase(): Promise<void> {
    if (!active) throw new DriveMemoryError('Connect your memory drive before saving.')
    if (timer) clearTimeout(timer)
    timer = undefined
    dirty = true
    if (pending) {
        const requested = generation
        await pending
        if (!active || generation !== requested)
            throw new DriveMemoryError('The memory drive changed while saving.')
        if (dirty) return syncDriveDatabase()
        return
    }
    const current = generation
    pending = (async () => {
        do {
            dirty = false
            let retries = 0
            while (true) {
                try {
                    await saveCurrentState(current)
                    break
                } catch (error) {
                    if (
                        !(error instanceof DatabaseBusyError) ||
                        retries++ >= 30 ||
                        !active ||
                        generation !== current
                    )
                        throw error
                    await new Promise<void>((resolve) => setTimeout(resolve, 100))
                }
            }
        } while (dirty && active && generation === current)
    })()
        .catch((error) => {
            driveMemory.invalidate(error)
            throw error
        })
        .finally(() => {
            pending = undefined
        })
    return pending
}

/** Called after app migrations/default setup. The integration module owns UI session cleanup. */
export async function initializeDriveSession(): Promise<void> {
    installListeners()
    const { restoreConnectedDriveSession } = await import('./driveIntegration')
    try {
        await restoreConnectedDriveSession()
    } catch {
        /* A missing/unreadable USB is recoverable in the Memory screen; no phone fallback. */
    }
}
