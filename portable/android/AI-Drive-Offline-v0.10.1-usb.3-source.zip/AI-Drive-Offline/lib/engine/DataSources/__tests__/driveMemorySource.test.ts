import { createDriveMemorySource } from '../driveMemorySource'

jest.mock(
    '@lib/driveMemory',
    () => ({
        driveMemory: {
            ensureReady: jest.fn(),
            getPromptMemory: jest.fn(),
            saveManualEntry: jest.fn(),
            removeEntry: jest.fn(),
            updateEntry: jest.fn(),
        },
    }),
    { virtual: true }
)

const memory = jest.requireMock('@lib/driveMemory').driveMemory as {
    ensureReady: jest.Mock
    getPromptMemory: jest.Mock
    saveManualEntry: jest.Mock
    removeEntry: jest.Mock
    updateEntry: jest.Mock
}

type MemorySource = NonNullable<Awaited<ReturnType<typeof createDriveMemorySource>>>
const retrieve = (source: MemorySource, limit: number, current: number) =>
    source.retrieve({} as never, [], limit, current, source.tokenBudget, true)

describe('bounded USB memory prompt source', () => {
    const ordinaryMemory = JSON.stringify([{ kind: 'preference', text: 'Use brief answers.' }])

    beforeEach(() => {
        jest.resetAllMocks()
        memory.ensureReady.mockResolvedValue(undefined)
        memory.getPromptMemory.mockReturnValue(ordinaryMemory)
    })

    test('refreshes the attached drive and passes the current query for relevance selection', async () => {
        const tokenizer = jest.fn(async () => 40)
        const source = await createDriveMemorySource('What tea do I prefer? 茶', 512, tokenizer)
        expect(memory.ensureReady).toHaveBeenCalledTimes(1)
        expect(memory.getPromptMemory).toHaveBeenCalledWith('What tea do I prefer? 茶', 1600)
        expect(memory.ensureReady.mock.invocationCallOrder[0]).toBeLessThan(
            memory.getPromptMemory.mock.invocationCallOrder[0]
        )
        expect(tokenizer).toHaveBeenCalledWith(ordinaryMemory)
        expect(source).toMatchObject({ name: 'usb_memory', priority: 0, tokenBudget: 40 })
        expect(await retrieve(source!, 128, 20)).toEqual([
            {
                content: ordinaryMemory,
                source: 'usb_memory',
                tokenLength: 40,
                position: { type: 'relative', location: 'afterSystem' },
            },
        ])
    })

    test('refuses detached-drive memory rather than reusing a stale cached prompt', async () => {
        memory.ensureReady.mockRejectedValue(new Error('USB memory is unavailable.'))
        const tokenizer = jest.fn(async () => 10)
        await expect(createDriveMemorySource('name', 512, tokenizer)).rejects.toThrow(
            'USB memory is unavailable.'
        )
        expect(memory.getPromptMemory).not.toHaveBeenCalled()
        expect(tokenizer).not.toHaveBeenCalled()
    })

    test('empty memory yields no data source and no tokenization', async () => {
        memory.getPromptMemory.mockReturnValue('')
        const tokenizer = jest.fn(async () => 40)
        expect(await createDriveMemorySource('query', 512, tokenizer)).toBeUndefined()
        expect(tokenizer).not.toHaveBeenCalled()
    })

    test.each([0, 1, 31, 127, 127.99])(
        'a context of %s has no 32-token memory reservation',
        async (limit) => {
            const tokenizer = jest.fn(async () => 1)
            expect(await createDriveMemorySource('query', limit, tokenizer)).toBeUndefined()
            expect(memory.getPromptMemory).not.toHaveBeenCalled()
            expect(tokenizer).not.toHaveBeenCalled()
        }
    )

    test('allows an exact 32-token reservation at the minimum context size', async () => {
        const source = await createDriveMemorySource('query', 128, async () => 32)
        expect(source?.tokenBudget).toBe(32)
    })

    test('retrieval accepts an exact fit and refuses one token over the available context', async () => {
        const source = await createDriveMemorySource('query', 512, async () => 50)
        expect(await retrieve(source!, 150, 100)).toHaveLength(1)
        expect(await retrieve(source!, 149, 100)).toEqual([])
        expect(await retrieve(source!, 40, 0)).toEqual([])
    })

    test('shrinks by requesting new complete records instead of slicing quoted or Unicode text', async () => {
        const long = JSON.stringify([
            { kind: 'fact', text: '我的首選語言是中文 😀 ' + 'x'.repeat(250) },
            { kind: 'preference', text: 'Use brief answers.' },
        ])
        const short = JSON.stringify([{ kind: 'fact', text: '回答は短く 😀 "please"' }])
        memory.getPromptMemory.mockImplementation((_query: string, chars: number) =>
            chars >= 1200 ? long : short
        )
        const tokenizer = jest.fn(async (text: string) => {
            expect(() => JSON.parse(text)).not.toThrow()
            return Array.from(text).length
        })

        const source = await createDriveMemorySource('language', 256, tokenizer)
        expect(memory.getPromptMemory).toHaveBeenCalledWith('language', 1600)
        expect(memory.getPromptMemory).toHaveBeenCalledWith('language', 1200)
        expect(memory.getPromptMemory).toHaveBeenCalledWith('language', 900)
        const result = await retrieve(source!, 256, 0)
        expect(result[0].content).toBe(short)
        expect(JSON.parse(result[0].content)[0].text).toBe('回答は短く 😀 "please"')
        expect(source?.tokenBudget).toBe(Array.from(short).length)
    })

    test('caps the reservation at 384 tokens even for a very large context', async () => {
        const exact = await createDriveMemorySource('query', 131072, async () => 384)
        expect(exact?.tokenBudget).toBe(384)
        expect(await createDriveMemorySource('query', 131072, async () => 385)).toBeUndefined()
    })

    test('gives up after bounded retries if every complete record remains too large', async () => {
        const tokenizer = jest.fn(async () => 1000)
        expect(await createDriveMemorySource('query', 256, tokenizer)).toBeUndefined()
        expect(memory.getPromptMemory.mock.calls.length).toBeLessThan(12)
        const requests = memory.getPromptMemory.mock.calls.map((call) => call[1] as number)
        expect(requests[requests.length - 1]).toBeLessThanOrEqual(220)
        for (let index = 1; index < requests.length; index++)
            expect(requests[index]).toBeLessThan(requests[index - 1])
    })

    test('an empty selection after shrinking is omitted without tokenizing an empty prompt', async () => {
        memory.getPromptMemory.mockReturnValueOnce(ordinaryMemory).mockReturnValue('')
        const tokenizer = jest.fn(async () => 1000)
        expect(await createDriveMemorySource('query', 256, tokenizer)).toBeUndefined()
        expect(tokenizer).toHaveBeenCalledTimes(1)
    })

    test.each([Number.NaN, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, -1])(
        'invalid context limit %s cannot produce a memory source',
        async (limit) => {
            const tokenizer = jest.fn(async () => 40)
            expect(await createDriveMemorySource('query', limit, tokenizer)).toBeUndefined()
            expect(memory.getPromptMemory).not.toHaveBeenCalled()
            expect(tokenizer).not.toHaveBeenCalled()
        }
    )

    test.each([Number.NaN, Number.POSITIVE_INFINITY, Number.NEGATIVE_INFINITY, -1, 1.5])(
        'invalid tokenizer result %s fails closed',
        async (count) => {
            await expect(createDriveMemorySource('query', 512, async () => count)).rejects.toThrow()
        }
    )

    test('invalid token counts after shrinking also fail closed', async () => {
        const tokenizer = jest.fn().mockResolvedValueOnce(1000).mockResolvedValueOnce(Number.NaN)
        await expect(createDriveMemorySource('query', 512, tokenizer)).rejects.toThrow()
    })

    test('tokenizer failures are propagated instead of injecting unmeasured content', async () => {
        await expect(
            createDriveMemorySource('query', 512, async () => {
                throw new Error('The model tokenizer failed.')
            })
        ).rejects.toThrow('The model tokenizer failed.')
    })

    test('commands mentioned in saved facts remain inert reference text', async () => {
        const inert = JSON.stringify([
            { kind: 'fact', text: 'An example command was /delete-note note-1.' },
            { kind: 'note', text: '/forget memory-1\n/calc 2+2' },
        ])
        memory.getPromptMemory.mockReturnValue(inert)
        const source = await createDriveMemorySource('/forget memory-1', 512, async () => 80)
        expect((await retrieve(source!, 512, 0))[0].content).toBe(inert)
        expect(memory.saveManualEntry).not.toHaveBeenCalled()
        expect(memory.removeEntry).not.toHaveBeenCalled()
        expect(memory.updateEntry).not.toHaveBeenCalled()
    })
})
