import { driveMemory } from '@lib/driveMemory'

import { DataSource } from './types'

/** Persist everything; inject only a bounded selection into a model's active context. */
export async function createDriveMemorySource(
    query: string,
    maxLength: number,
    tokenizer: (text: string) => Promise<number>
): Promise<DataSource | undefined> {
    if (!Number.isFinite(maxLength) || maxLength < 0) return
    await driveMemory.ensureReady()
    const budget = Math.min(384, Math.floor(maxLength / 4))
    if (budget < 32) return
    let chars = 1600
    let content = driveMemory.getPromptMemory(query, chars)
    if (!content) return
    const count = async (text: string) => {
        const value = await tokenizer(text)
        if (!Number.isInteger(value) || value < 0) throw new Error('Invalid memory token count.')
        return value
    }
    let tokenLength = await count(content)
    // Ask the memory store for fewer complete JSON records; never cut a quoted fact.
    while (tokenLength > budget && chars > 220) {
        chars = Math.floor(chars * 0.75)
        content = driveMemory.getPromptMemory(query, chars)
        if (!content) return
        tokenLength = await count(content)
    }
    if (tokenLength > budget) return
    return {
        name: 'usb_memory',
        priority: 0,
        tokenBudget: tokenLength,
        retrieve: async (_params, _messages, limit, current) =>
            current + tokenLength > limit
                ? []
                : [
                      {
                          content,
                          source: 'usb_memory',
                          tokenLength,
                          position: { type: 'relative', location: 'afterSystem' },
                      },
                  ],
    }
}
