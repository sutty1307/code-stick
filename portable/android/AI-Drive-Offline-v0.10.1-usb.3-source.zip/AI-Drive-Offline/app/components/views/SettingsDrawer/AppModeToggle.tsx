import { useTranslation } from 'react-i18next'
import { Platform } from 'react-native'

import HorizontalSelector from '@components/input/HorizontalSelector'

const AppModeToggle = () => {
    const { t } = useTranslation()

    return (
        <HorizontalSelector
            style={{ flex: 0, paddingBottom: 12, paddingHorizontal: 8, marginHorizontal: 4 }}
            values={[
                {
                    value: 'local',
                    label: t('appMode.options.local'),
                    icon: Platform.OS === 'android' ? 'phone-android' : 'phone-iphone',
                },
            ]}
            selected="local"
            onPress={() => {}}
        />
    )
}

export default AppModeToggle
