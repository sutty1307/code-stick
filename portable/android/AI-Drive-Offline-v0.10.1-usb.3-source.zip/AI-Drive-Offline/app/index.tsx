import AntDesign from '@react-native-vector-icons/ant-design/static'
import { useMigrations } from 'drizzle-orm/expo-sqlite/migrator'
import { Redirect, SplashScreen } from 'expo-router'
import { useEffect, useState, useSyncExternalStore } from 'react'
import { useTranslation } from 'react-i18next'
import { Linking, StyleSheet, Text, TouchableOpacity, View } from 'react-native'

import ThemedButton from '@components/buttons/ThemedButton'
import HeaderTitle from '@components/views/HeaderTitle'
import { db } from '@db/db'
import {
    initializeDriveSession,
    isDriveSessionReady,
    subscribeDriveSession,
} from '@lib/driveDatabase'
import useLocalAuth from '@lib/hooks/LocalAuth'
import { Theme } from '@lib/theme/ThemeManager'
import { loadChatOnInit, startupApp, useTextIntentFocus } from '@lib/utils/Startup'
import CharacterList from '@screens/CharacterListScreen'

import migrations from '../db/migrations/migrations'

// A Home route can be mounted many times. Startup/default creation and drive restoration
// must run once per app process, before exposing any chat data.
let bootstrapPromise: Promise<void> | undefined
let startupChatLoaded = false
const bootstrap = () => {
    if (!bootstrapPromise)
        bootstrapPromise = Promise.resolve().then(startupApp).then(initializeDriveSession)
    return bootstrapPromise
}
const resetBootstrap = () => {
    bootstrapPromise = undefined
}

const useStartupRoutine = () => {
    const { success, error } = useMigrations(db, migrations)
    const { authorized, retry } = useLocalAuth()
    const [initialized, setInitialized] = useState(false)
    const [startupError, setStartupError] = useState<Error>()
    const [attempt, setAttempt] = useState(0)
    const sessionReady = useSyncExternalStore(
        subscribeDriveSession,
        isDriveSessionReady,
        () => false
    )

    useTextIntentFocus()

    useEffect(() => {
        if (authorized && initialized && sessionReady && !startupChatLoaded) {
            startupChatLoaded = true
            void loadChatOnInit().catch(() => {
                // A missing newest chat does not prevent opening the restored character list.
            })
        }
    }, [authorized, initialized, sessionReady])

    useEffect(() => {
        if (error || (success && !authorized)) void SplashScreen.hideAsync()
        if (!success || !authorized) return
        let cancelled = false
        void bootstrap()
            .then(() => {
                if (!cancelled) setInitialized(true)
            })
            .catch((cause) => {
                if (!cancelled)
                    setStartupError(
                        cause instanceof Error ? cause : new Error('App startup failed.')
                    )
            })
            .finally(() => {
                void SplashScreen.hideAsync()
            })
        return () => {
            cancelled = true
        }
    }, [success, authorized, error, attempt])

    const retryStartup = () => {
        resetBootstrap()
        setStartupError(undefined)
        setInitialized(false)
        setAttempt((value) => value + 1)
    }

    return { authorized, retry, error, initialized, sessionReady, startupError, retryStartup }
}

const Home = () => {
    const { color } = Theme.useTheme()
    const styles = useStyles()
    const { authorized, retry, error, initialized, sessionReady, startupError, retryStartup } =
        useStartupRoutine()
    const { t } = useTranslation()
    if (error)
        return (
            <View style={styles.centeredContainer}>
                <HeaderTitle />
                <Text style={styles.title}>{t('db.migrationerror.title')}</Text>
                <Text style={styles.errorLog}>{error.message}</Text>
                <Text style={styles.subtitle}>{t('db.migrationerror.description')}</Text>
                <Text style={styles.subtitle} />
                <ThemedButton
                    variant="secondary"
                    label="Github"
                    iconName="github"
                    iconSize={20}
                    onPress={() => {
                        Linking.openURL('https://github.com/Vali-98/ChatterUI')
                    }}
                />
            </View>
        )

    if (!authorized)
        return (
            <View style={[styles.centeredContainer, { rowGap: 60 }]}>
                <HeaderTitle />
                <AntDesign
                    name="lock"
                    size={120}
                    style={{ marginBottom: 12 }}
                    color={color.text._500}
                />
                <Text style={styles.title}>{t('auth.authorizationRequired')}</Text>
                <TouchableOpacity onPress={retry} style={styles.button}>
                    <Text style={styles.buttonText}>{t('common.actions.tryAgain')}</Text>
                </TouchableOpacity>
            </View>
        )
    if (startupError)
        return (
            <View style={styles.centeredContainer}>
                <HeaderTitle />
                <Text style={styles.title}>Unable to open your drive session</Text>
                <Text style={styles.subtitle}>{startupError.message}</Text>
                <ThemedButton label="Try again" variant="secondary" onPress={retryStartup} />
            </View>
        )
    if (initialized && !sessionReady) return <Redirect href="/screens/DriveMemoryScreen" />
    if (initialized && sessionReady) return <CharacterList />
    return <HeaderTitle />
}

export default Home

const useStyles = () => {
    const { color, spacing, fontSize, borderWidth } = Theme.useTheme()
    return StyleSheet.create({
        centeredContainer: {
            flex: 1,
            justifyContent: 'center',
            alignItems: 'center',
        },

        title: {
            color: color.text._300,
            fontSize: fontSize.xl2,
        },

        subtitle: {
            color: color.text._400,
            marginHorizontal: 24,
            textAlign: 'center',
        },

        errorLog: {
            color: color.text._400,
            fontSize: fontSize.s,
            paddingHorizontal: spacing.xl,
            paddingVertical: spacing.l,
            borderRadius: 12,
            margin: spacing.xl2,
            backgroundColor: 'black',
        },

        buttonText: {
            color: color.text._100,
        },

        button: {
            paddingVertical: spacing.l,
            paddingHorizontal: spacing.xl2,
            columnGap: spacing.m,
            borderRadius: spacing.xl2,
            borderWidth: borderWidth.m,
            borderColor: color.primary._500,
        },
    })
}
