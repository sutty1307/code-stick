/* eslint-disable i18next/no-literal-string */
import { Text, View } from 'react-native'

import HeaderTitle from '@components/views/HeaderTitle'
import { Theme } from '@lib/theme/ThemeManager'

const TTSManagerScreen = () => {
    const { color } = Theme.useTheme()
    return (
        <View style={{ padding: 24, rowGap: 16 }}>
            <HeaderTitle title="Speech" />
            <Text style={{ color: color.text._100, fontSize: 16, lineHeight: 24 }}>
                Speech is disabled in this local app. Your conversations are never passed to a
                separate speech provider.
            </Text>
        </View>
    )
}

export default TTSManagerScreen
