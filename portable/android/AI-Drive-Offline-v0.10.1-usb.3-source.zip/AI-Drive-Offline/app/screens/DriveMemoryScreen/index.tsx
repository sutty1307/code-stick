/* eslint-disable i18next/no-literal-string */
import { useRouter } from 'expo-router'
import { useEffect, useRef, useState, useSyncExternalStore } from 'react'
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'

import ThemedButton from '@components/buttons/ThemedButton'
import ThemedTextInput from '@components/input/ThemedTextInput'
import HeaderTitle from '@components/views/HeaderTitle'
import { isDriveSessionReady, subscribeDriveSession } from '@lib/driveDatabase'
import { connectDrive, continueDriveConversation, disconnectDrive } from '@lib/driveIntegration'
import { ConversationArchive, driveMemory, MemoryEntry, MemoryKind } from '@lib/driveMemory'
import { Theme } from '@lib/theme/ThemeManager'

const kinds: MemoryKind[] = ['preference', 'fact', 'note']
const labels: Record<MemoryKind, string> = {
    preference: 'Preference',
    fact: 'Fact',
    note: 'Note',
}
const displayTime = (value: string) => new Date(value).toLocaleString()

const DriveMemoryScreen = () => {
    const router = useRouter()
    const { color } = Theme.useTheme()
    const scrollRef = useRef<ScrollView>(null)
    const [state, setState] = useState(() => {
        const current = driveMemory.getState()
        return isDriveSessionReady() ? current : { ...current, entries: [] }
    })
    const folderRef = useRef(state.folderUri)
    const sessionRef = useRef(0)
    const [busy, setBusy] = useState(false)
    const [tab, setTab] = useState<'memory' | 'conversations'>('memory')
    const [kind, setKind] = useState<MemoryKind>('preference')
    const [text, setText] = useState('')
    const [title, setTitle] = useState('')
    const [editingId, setEditingId] = useState<string>()
    const [visibleCount, setVisibleCount] = useState(20)
    const [conversations, setConversations] = useState<ConversationArchive[]>([])
    const [viewing, setViewing] = useState<ConversationArchive>()
    const sessionReady = useSyncExternalStore(
        subscribeDriveSession,
        isDriveSessionReady,
        () => false
    )
    const available = state.status === 'ready' && sessionReady

    useEffect(() => {
        const clearView = () => {
            sessionRef.current += 1
            setConversations([])
            setViewing(undefined)
            setEditingId(undefined)
            setText('')
            setTitle('')
        }
        const unsubscribeMemory = driveMemory.subscribe(() => {
            const next = driveMemory.getState()
            setState(isDriveSessionReady() ? next : { ...next, entries: [] })
            if (
                folderRef.current !== next.folderUri ||
                next.status === 'unavailable' ||
                next.status === 'not-configured' ||
                next.status === 'error'
            ) {
                clearView()
            }
            folderRef.current = next.folderUri
        })
        const unsubscribeSession = subscribeDriveSession(() => {
            const next = driveMemory.getState()
            if (isDriveSessionReady()) setState(next)
            else {
                clearView()
                setState({ ...next, entries: [] })
            }
        })
        return () => {
            unsubscribeMemory()
            unsubscribeSession()
        }
    }, [])

    const run = async (operation: () => Promise<void>) => {
        if (busy) return
        setBusy(true)
        try {
            await operation()
        } catch (error) {
            Alert.alert(
                'Drive unavailable',
                error instanceof Error ? error.message : 'Reconnect the USB drive and try again.'
            )
        } finally {
            setBusy(false)
        }
    }

    const resetEditor = () => {
        setEditingId(undefined)
        setText('')
        setTitle('')
    }

    const save = () =>
        void run(async () => {
            const entry = {
                kind: kind,
                text: text.trim(),
                title: kind === 'note' ? title.trim() || undefined : undefined,
            }
            if (editingId) await driveMemory.updateEntry(editingId, entry)
            else await driveMemory.saveManualEntry(entry)
            resetEditor()
        })

    const edit = (entry: MemoryEntry) => {
        setEditingId(entry.id)
        setKind(entry.kind)
        setText(entry.text)
        setTitle(entry.title ?? '')
        scrollRef.current?.scrollTo({ y: 0, animated: true })
    }

    const remove = (entry: MemoryEntry) =>
        Alert.alert(
            'Delete saved memory?',
            'This removes the saved memory from the drive. Its original chat message remains in conversation history.',
            [
                { text: 'Cancel', style: 'cancel' },
                {
                    text: 'Delete',
                    style: 'destructive',
                    onPress: () =>
                        void run(async () => {
                            await driveMemory.removeEntry(entry.id)
                            if (editingId === entry.id) resetEditor()
                        }),
                },
            ]
        )

    const loadConversations = () =>
        void run(async () => {
            const session = sessionRef.current
            const list = await driveMemory.listConversations()
            if (session !== sessionRef.current) return
            setConversations(list.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)))
            setViewing(undefined)
            setTab('conversations')
            setVisibleCount(20)
        })

    const viewConversation = (id: string) =>
        void run(async () => {
            const session = sessionRef.current
            const conversation = await driveMemory.getConversation(id)
            if (session !== sessionRef.current) return
            setViewing(conversation)
            setVisibleCount(20)
        })

    const disconnect = () =>
        Alert.alert(
            'Save and disconnect?',
            'Pending changes will save to the drive. Personal data will be cleared from this app session. Your saved files stay on the drive.',
            [
                { text: 'Cancel', style: 'cancel' },
                { text: 'Save and disconnect', onPress: () => void run(disconnectDrive) },
            ]
        )

    const status = available
        ? 'Drive connected'
        : state.status === 'syncing'
          ? 'Saving / checking drive…'
          : state.status === 'ready'
            ? 'Drive selected; session is not loaded'
            : state.status === 'not-configured'
              ? 'Choose your USB memory folder'
              : 'Drive unavailable'
    const entries = [...state.entries].sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
    const statusColor =
        state.status === 'unavailable' || state.status === 'error'
            ? color.error._400
            : color.text._100

    return (
        <SafeAreaView edges={['bottom']} style={{ flex: 1 }}>
            <HeaderTitle title="Drive Memory" />
            <ScrollView
                ref={scrollRef}
                keyboardShouldPersistTaps="handled"
                contentContainerStyle={styles.content}>
                <View
                    style={[
                        styles.card,
                        { backgroundColor: color.neutral._200, borderColor: color.neutral._400 },
                    ]}>
                    <Text
                        style={[styles.heading, { color: statusColor }]}
                        accessibilityRole="header">
                        {status}
                    </Text>
                    <Text style={[styles.body, { color: color.text._100 }]}>
                        No internet permission. Data saves to the selected drive. Chats, saved
                        preferences, facts, and notes stay with that drive between app sessions.
                    </Text>
                    {available && (
                        <Text style={[styles.caption, { color: color.text._400 }]}>
                            Verified save #{state.revision} · {state.entries.length} memories ·{' '}
                            {state.conversationCount} conversations
                        </Text>
                    )}
                    {available && state.lastVerifiedAt && (
                        <Text style={[styles.caption, { color: color.text._400 }]}>
                            Last checked: {displayTime(state.lastVerifiedAt)}
                        </Text>
                    )}
                    {state.error && (
                        <Text style={[styles.body, { color: color.error._400 }]}>
                            {state.error}
                        </Text>
                    )}
                    {state.recoveredFromCorruption && (
                        <Text style={[styles.body, { color: color.text._100 }]}>
                            An interrupted snapshot was found. The last verified save was restored.
                        </Text>
                    )}
                    {!available && state.status !== 'syncing' && (
                        <Text style={[styles.body, { color: color.text._400 }]}>
                            Choose the memory folder on your connected USB drive. Tap Use this
                            folder, then Allow. Keep the drive connected while chatting.
                        </Text>
                    )}
                    <View style={styles.row}>
                        <ThemedButton
                            label={
                                state.folderUri
                                    ? 'Reconnect / choose folder'
                                    : 'Choose USB memory folder'
                            }
                            iconName="folder-open"
                            variant={busy || state.status === 'syncing' ? 'disabled' : 'primary'}
                            onPress={() => void run(connectDrive)}
                        />
                        {available && (
                            <ThemedButton
                                label="Save and disconnect"
                                variant={busy ? 'disabled' : 'secondary'}
                                onPress={disconnect}
                            />
                        )}
                    </View>
                </View>
                <View style={styles.row}>
                    {available && (
                        <ThemedButton
                            label="Choose a model"
                            variant={busy ? 'disabled' : 'primary'}
                            onPress={() => router.push('/screens/ModelManagerScreen')}
                        />
                    )}
                    <ThemedButton
                        label="Chats"
                        variant="secondary"
                        onPress={() => router.replace('/')}
                    />
                    <ThemedButton
                        label="Offline Toolkit"
                        variant="secondary"
                        onPress={() => router.push('/screens/DriveToolkitScreen')}
                    />
                </View>
                <View style={styles.row}>
                    <ThemedButton
                        label="Memories"
                        variant={tab === 'memory' ? 'primary' : 'secondary'}
                        onPress={() => {
                            setTab('memory')
                            setViewing(undefined)
                            setVisibleCount(20)
                        }}
                    />
                    <ThemedButton
                        label="Saved conversations"
                        variant={
                            !available || busy
                                ? 'disabled'
                                : tab === 'conversations'
                                  ? 'primary'
                                  : 'secondary'
                        }
                        onPress={loadConversations}
                    />
                </View>
                {sessionReady &&
                    (tab === 'memory' ? (
                        <>
                            <Text
                                style={[styles.heading, { color: color.text._100 }]}
                                accessibilityRole="header">
                                {editingId ? 'Edit memory' : 'Add memory'}
                            </Text>
                            <Text style={[styles.body, { color: color.text._400 }]}>
                                All chat messages save automatically. Clear statements such as “I
                                prefer short answers” or “Remember that…” also become saved
                                memories. Review or edit them here.
                            </Text>
                            <View style={styles.row}>
                                {kinds.map((value) => (
                                    <ThemedButton
                                        key={value}
                                        label={labels[value]}
                                        variant={kind === value ? 'primary' : 'secondary'}
                                        onPress={() => setKind(value)}
                                    />
                                ))}
                            </View>
                            {kind === 'note' && (
                                <ThemedTextInput
                                    label="Note title (optional)"
                                    value={title}
                                    onChangeText={setTitle}
                                    maxLength={120}
                                    containerStyle={{ flex: 0 }}
                                />
                            )}
                            <ThemedTextInput
                                label="Memory text"
                                value={text}
                                onChangeText={setText}
                                multiline
                                numberOfLines={4}
                                maxLength={2000}
                                editable={available && !busy}
                                containerStyle={{ flex: 0 }}
                            />
                            <View style={styles.row}>
                                <ThemedButton
                                    label={editingId ? 'Save changes to drive' : 'Save to drive'}
                                    iconName="save"
                                    variant={
                                        !available || busy || !text.trim() ? 'disabled' : 'primary'
                                    }
                                    onPress={save}
                                />
                                {editingId && (
                                    <ThemedButton
                                        label="Cancel edit"
                                        variant="secondary"
                                        onPress={resetEditor}
                                    />
                                )}
                            </View>
                            <Text
                                style={[styles.heading, { color: color.text._100 }]}
                                accessibilityRole="header">
                                Saved memories ({entries.length})
                            </Text>
                            {available && !entries.length && (
                                <Text style={[styles.body, { color: color.text._400 }]}>
                                    No saved memories yet. Add one above or use /remember in a chat.
                                </Text>
                            )}
                            {entries.slice(0, visibleCount).map((entry) => (
                                <View
                                    key={entry.id}
                                    style={[styles.card, { borderColor: color.neutral._400 }]}>
                                    <Text style={[styles.heading, { color: color.text._100 }]}>
                                        {labels[entry.kind]}
                                        {entry.title ? ` · ${entry.title}` : ''}
                                    </Text>
                                    <Text
                                        selectable
                                        style={[styles.body, { color: color.text._100 }]}>
                                        {entry.text}
                                    </Text>
                                    <Text style={[styles.caption, { color: color.text._400 }]}>
                                        {entry.source.type === 'user-message'
                                            ? 'Saved from your message'
                                            : 'Added manually'}{' '}
                                        · {displayTime(entry.updatedAt)}
                                    </Text>
                                    <View style={styles.row}>
                                        <ThemedButton
                                            label="Edit"
                                            variant={!available || busy ? 'disabled' : 'secondary'}
                                            onPress={() => edit(entry)}
                                        />
                                        <ThemedButton
                                            label="Delete"
                                            variant={!available || busy ? 'disabled' : 'critical'}
                                            onPress={() => remove(entry)}
                                        />
                                    </View>
                                </View>
                            ))}
                            {entries.length > visibleCount && (
                                <ThemedButton
                                    label="Show more memories"
                                    variant="secondary"
                                    onPress={() => setVisibleCount(visibleCount + 20)}
                                />
                            )}
                        </>
                    ) : viewing ? (
                        <>
                            <ThemedButton
                                label="Back to saved conversations"
                                variant="secondary"
                                onPress={() => setViewing(undefined)}
                            />
                            <Text
                                style={[styles.heading, { color: color.text._100 }]}
                                accessibilityRole="header">
                                {viewing.title || 'Saved conversation'}
                            </Text>
                            <ThemedButton
                                label="Continue this conversation"
                                variant={!available || busy ? 'disabled' : 'primary'}
                                onPress={() =>
                                    void run(async () => {
                                        const session = sessionRef.current
                                        const id = await continueDriveConversation(viewing.id)
                                        if (session !== sessionRef.current) return
                                        if (id) router.replace('/screens/ChatScreen')
                                        else
                                            Alert.alert(
                                                'Conversation unavailable',
                                                'This saved conversation could not be opened.'
                                            )
                                    })
                                }
                            />
                            {viewing.messages.length > visibleCount && (
                                <ThemedButton
                                    label="Show earlier messages"
                                    variant="secondary"
                                    onPress={() => setVisibleCount(visibleCount + 20)}
                                />
                            )}
                            {viewing.messages.slice(-visibleCount).map((message, index) => (
                                <View
                                    key={`${message.id ?? index}-${index}`}
                                    style={[styles.card, { borderColor: color.neutral._400 }]}>
                                    <Text style={[styles.caption, { color: color.text._400 }]}>
                                        {message.role === 'user'
                                            ? 'You'
                                            : message.role === 'assistant'
                                              ? 'AI'
                                              : 'System'}
                                        {message.createdAt
                                            ? ` · ${displayTime(message.createdAt)}`
                                            : ''}
                                    </Text>
                                    <Text
                                        selectable
                                        style={[styles.body, { color: color.text._100 }]}>
                                        {message.text}
                                    </Text>
                                </View>
                            ))}
                        </>
                    ) : (
                        <>
                            <Text
                                style={[styles.heading, { color: color.text._100 }]}
                                accessibilityRole="header">
                                Saved conversations ({conversations.length})
                            </Text>
                            {!conversations.length && (
                                <Text style={[styles.body, { color: color.text._400 }]}>
                                    No saved conversations yet. Your chats will appear here after
                                    they save to the drive.
                                </Text>
                            )}
                            {conversations.slice(0, visibleCount).map((conversation) => (
                                <View
                                    key={conversation.id}
                                    style={[styles.card, { borderColor: color.neutral._400 }]}>
                                    <Text style={[styles.heading, { color: color.text._100 }]}>
                                        {conversation.title || 'Saved conversation'}
                                    </Text>
                                    <Text style={[styles.caption, { color: color.text._400 }]}>
                                        {conversation.messages.length} messages ·{' '}
                                        {displayTime(conversation.updatedAt)}
                                    </Text>
                                    <ThemedButton
                                        label="View conversation"
                                        variant={!available || busy ? 'disabled' : 'secondary'}
                                        onPress={() => viewConversation(conversation.id)}
                                    />
                                </View>
                            ))}
                            {conversations.length > visibleCount && (
                                <ThemedButton
                                    label="Show more conversations"
                                    variant="secondary"
                                    onPress={() => setVisibleCount(visibleCount + 20)}
                                />
                            )}
                        </>
                    ))}
                <Text style={[styles.caption, { color: color.text._400 }]}>
                    The drive files are not encrypted. Before unplugging, use Save and disconnect.
                    To erase personal data from the drive, delete both drive-memory-a.json and
                    drive-memory-b.json from the selected folder using Files.
                </Text>
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    content: { padding: 16, paddingBottom: 32, rowGap: 16 },
    card: { borderWidth: 1, borderRadius: 12, padding: 16, rowGap: 12 },
    heading: { fontSize: 18, fontWeight: '600' },
    body: { fontSize: 15, lineHeight: 23 },
    caption: { fontSize: 13, lineHeight: 20 },
    row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
})

export default DriveMemoryScreen
