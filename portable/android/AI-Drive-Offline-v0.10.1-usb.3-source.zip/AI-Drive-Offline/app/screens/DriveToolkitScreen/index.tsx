/* eslint-disable i18next/no-literal-string */
import { useRouter } from 'expo-router'
import { useEffect, useRef, useState } from 'react'
import { Alert, ScrollView, StyleSheet, Text, View } from 'react-native'
import { SafeAreaView } from 'react-native-safe-area-context'

import ThemedButton from '@components/buttons/ThemedButton'
import ThemedTextInput from '@components/input/ThemedTextInput'
import HeaderTitle from '@components/views/HeaderTitle'
import { isDriveSessionReady, subscribeDriveSession } from '@lib/driveDatabase'
import { executeDriveCommand } from '@lib/driveIntegration'
import { driveMemory } from '@lib/driveMemory'
import { DRIVE_TOOL_HELP } from '@lib/driveTools'
import { Theme } from '@lib/theme/ThemeManager'

const examples = [
    { label: 'Calculator', command: '/calc (12 + 8) * 3' },
    { label: 'Remember', command: '/remember I prefer brief answers' },
    { label: 'Memories', command: '/memories' },
    { label: 'Save note', command: '/note Shopping | Milk, bread, apples' },
    { label: 'Notes', command: '/notes' },
    { label: 'Help', command: '/help' },
]

const DriveToolkitScreen = () => {
    const router = useRouter()
    const { color } = Theme.useTheme()
    const [input, setInput] = useState('/help')
    const [output, setOutput] = useState(DRIVE_TOOL_HELP)
    const [busy, setBusy] = useState(false)
    const folderRef = useRef(driveMemory.getState().folderUri)
    const sessionRef = useRef(0)

    useEffect(() => {
        const clearOutput = () => {
            sessionRef.current += 1
            setInput('/help')
            setOutput(DRIVE_TOOL_HELP)
        }
        const unsubscribeMemory = driveMemory.subscribe(() => {
            const state = driveMemory.getState()
            if (
                folderRef.current !== state.folderUri ||
                state.status === 'unavailable' ||
                state.status === 'not-configured' ||
                state.status === 'error'
            ) {
                clearOutput()
            }
            folderRef.current = state.folderUri
        })
        const unsubscribeSession = subscribeDriveSession(() => {
            if (!isDriveSessionReady()) clearOutput()
        })
        return () => {
            unsubscribeMemory()
            unsubscribeSession()
        }
    }, [])

    const run = async () => {
        if (busy || !input.trim()) return
        const session = sessionRef.current
        setBusy(true)
        try {
            const result = await executeDriveCommand(input)
            if (session === sessionRef.current)
                setOutput(result ?? 'Choose a tool command below, or type /help.')
        } catch (error) {
            const message = error instanceof Error ? error.message : 'The tool could not run.'
            if (session === sessionRef.current) setOutput(message)
            Alert.alert('Tool unavailable', message)
        } finally {
            setBusy(false)
        }
    }

    return (
        <SafeAreaView edges={['bottom']} style={{ flex: 1 }}>
            <HeaderTitle title="Offline Toolkit" />
            <ScrollView keyboardShouldPersistTaps="handled" contentContainerStyle={styles.content}>
                <Text style={[styles.intro, { color: color.text._100 }]}>
                    Calculate, save notes, and manage remembered facts without an internet
                    connection. You can also type these commands in a chat.
                </Text>
                <View style={styles.row}>
                    <ThemedButton
                        label="Drive Memory"
                        variant="secondary"
                        iconName="save"
                        onPress={() => router.push('/screens/DriveMemoryScreen')}
                    />
                    <ThemedButton
                        label="Chats"
                        variant="secondary"
                        onPress={() => router.replace('/')}
                    />
                </View>
                <View style={styles.row}>
                    {examples.map((example) => (
                        <ThemedButton
                            key={example.label}
                            label={example.label}
                            variant="secondary"
                            onPress={() => setInput(example.command)}
                        />
                    ))}
                </View>
                <ThemedTextInput
                    label="Tool command"
                    value={input}
                    onChangeText={setInput}
                    multiline
                    numberOfLines={3}
                    autoCapitalize="none"
                    autoCorrect={false}
                    maxLength={2300}
                    containerStyle={{ flex: 0 }}
                    accessibilityLabel="Offline tool command"
                />
                <ThemedButton
                    label={busy ? 'Running…' : 'Run tool'}
                    iconName="play-circle"
                    variant={busy || !input.trim() ? 'disabled' : 'primary'}
                    onPress={() => void run()}
                />
                <View
                    style={[
                        styles.result,
                        { backgroundColor: color.neutral._200, borderColor: color.neutral._400 },
                    ]}>
                    <Text
                        style={[styles.heading, { color: color.text._100 }]}
                        accessibilityRole="header">
                        Result
                    </Text>
                    <Text selectable style={[styles.output, { color: color.text._100 }]}>
                        {output}
                    </Text>
                </View>
                <Text style={[styles.caption, { color: color.text._400 }]}>
                    Only commands you submit run tools. Model replies cannot run them. Notes and
                    memories save to the selected USB drive. This app has no internet permission.
                </Text>
            </ScrollView>
        </SafeAreaView>
    )
}

const styles = StyleSheet.create({
    content: { padding: 16, paddingBottom: 32, rowGap: 16 },
    intro: { fontSize: 16, lineHeight: 24 },
    row: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
    result: { borderWidth: 1, borderRadius: 12, padding: 16, rowGap: 12 },
    heading: { fontSize: 18, fontWeight: '600' },
    output: { fontSize: 15, lineHeight: 24 },
    caption: { fontSize: 13, lineHeight: 20 },
})

export default DriveToolkitScreen
