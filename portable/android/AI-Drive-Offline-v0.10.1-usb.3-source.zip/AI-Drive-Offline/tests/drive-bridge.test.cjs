const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const { createRequire } = require('node:module');
const { DatabaseSync } = require('node:sqlite');

// Runs the actual app bridge against SQLite, not a mock SQL parser. Android file
// and SAF calls are isolated in memory; native Android integration is not claimed.
const root = path.resolve(__dirname, '..');
const nativeRequire = createRequire(path.join(root, 'package.json'));
const ts = nativeRequire('typescript');
function load(relative, dependencies = {}) {
  const filename = path.join(root, relative);
  const compiled = ts.transpileModule(fs.readFileSync(filename, 'utf8'), {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2022 },
    fileName: filename,
  }).outputText;
  const module = { exports: {} };
  const req = (id) => Object.prototype.hasOwnProperty.call(dependencies, id) ? dependencies[id] : nativeRequire(id);
  new Function('require', 'module', 'exports', compiled)(req, module, module.exports);
  return module.exports;
}
const schema = load('db/schema.ts');
const { is } = nativeRequire('drizzle-orm');
const { SQLiteTable, getTableConfig } = nativeRequire('drizzle-orm/sqlite-core');
const configs = Object.values(schema).filter((table) => is(table, SQLiteTable)).map(getTableConfig);
const q = (name) => '"' + name.replaceAll('"', '""') + '"';
const clone = (value) => structuredClone(value);
const { SessionValues } = load('lib/storage/SessionValues.ts');
const { Storage } = load('lib/enums/Storage.ts');

function harness() {
  const sql = new DatabaseSync(':memory:');
  for (const config of configs) {
    const columns = config.columns.map((column) => [q(column.name), column.getSQLType(),
      column.notNull ? 'NOT NULL' : '', column.primary ? 'PRIMARY KEY' : '', column.autoIncrement ? 'AUTOINCREMENT' : '', column.isUnique ? 'UNIQUE' : ''].join(' '));
    columns.push(...config.primaryKeys.map((key) => `PRIMARY KEY (${key.columns.map((column) => q(column.name)).join(',')})`));
    columns.push(...config.uniqueConstraints.map((key) => `UNIQUE (${key.columns.map((column) => q(column.name)).join(',')})`));
    sql.exec(`CREATE TABLE ${q(config.name)} (${columns.join(',')})`);
  }
  let inTransaction = false;
  const operations = [];
  const sqliteDB = {
    isInTransactionSync: () => inTransaction,
    execSync: (statement) => {
      operations.push(statement);
      sql.exec(statement);
      if (statement === 'BEGIN') inTransaction = true;
      if (statement === 'COMMIT' || statement === 'ROLLBACK') inTransaction = false;
    },
    runSync: (statement, parameters = []) => { operations.push(statement); return sql.prepare(statement).run(...parameters); },
    getAllSync: (statement) => { operations.push(statement); return sql.prepare(statement).all().map((row) => ({ ...row })); },
  };
  const mmkv = new SessionValues();
  const files = new Map();
  const directories = new Set();
  const areas = { CharacterPath: 'cache:/characters/', Assets: 'cache:/assets/', Attachments: 'cache:/attachments/' };
  class File {
    constructor(uri, name = '') { this.uri = String(uri) + name; this.name = this.uri.split('/').pop(); }
    async base64() { return files.get(this.uri); }
    write(value) { files.set(this.uri, value); }
  }
  class Directory {
    constructor(uri) { this.uri = uri; }
    get exists() { return directories.has(this.uri); }
    list() { return [...files.keys()].filter((key) => key.startsWith(this.uri)).map((key) => new File(key)); }
    delete() { directories.delete(this.uri); for (const key of files.keys()) if (key.startsWith(this.uri)) files.delete(key); }
    create() { directories.add(this.uri); }
  }
  class DriveMemoryError extends Error {}
  const writes = [];
  let status = 'ready';
  const driveMemory = {
    ensureReady: async () => { if (status !== 'ready') throw new DriveMemoryError('USB unavailable'); },
    setApplicationState: async (value) => { writes.push(clone(value)); },
    getState: () => ({ status }),
    listConversations: async () => [],
    archiveConversation: async () => {},
    captureUserMessage: async () => {},
    removeConversation: async () => {},
    subscribe: () => () => {},
    invalidate: () => { status = 'unavailable'; },
  };
  const bridge = load('lib/driveDatabase.ts', {
    '@db/db': { sqliteDB }, '@db/schema': schema,
    '@lib/enums/Storage': { Storage }, '@lib/storage/MMKV': { mmkv },
    '@lib/utils/File': { AppDirectory: areas },
    'expo-file-system': { File, Directory },
    'expo-sqlite': { addDatabaseChangeListener: () => () => {} },
    './driveMemory': { driveMemory, DriveMemoryError, captureCandidate: () => undefined },
  });
  function insert(table, overrides) {
    const config = configs.find((item) => item.name === table);
    const row = Object.fromEntries(config.columns.map((column) => [column.name, !column.notNull && !column.primary ? null : column.getSQLType() === 'integer' ? 1 : '']));
    Object.assign(row, overrides);
    sql.prepare(`INSERT INTO ${q(table)} (${config.columns.map((column) => q(column.name)).join(',')}) VALUES (${config.columns.map(() => '?').join(',')})`).run(...config.columns.map((column) => row[column.name]));
  }
  return { sql, bridge, mmkv, files, directories, areas, sqliteDB, writes, driveMemory, operations, insert };
}

test('full schema, preferences, alternate replies and long text survive snapshot/restore', async () => {
  const h = harness();
  h.insert('characters', { id: 1, type: 'character', name: 'AI Bot' });
  h.insert('chats', { id: 2, character_id: 1, name: 'Full history' });
  h.insert('chat_entries', { id: 3, chat_id: 2, is_user: 1, name: 'User' });
  const text = 'Complete message '.repeat(2000);
  h.insert('chat_swipes', { id: 4, entry_id: 3, swipe: text, active: 1 });
  h.insert('chat_swipes', { id: 5, entry_id: 3, swipe: 'Preserved alternate reply', active: 0 });
  h.mmkv.set('personal-prefs', JSON.stringify({ theme: 'dark', userId: 1 }));
  const snapshot = await h.bridge.captureDriveApplicationState();
  assert.equal(snapshot.tables.length, configs.length);
  h.bridge.clearDriveDatabase();
  h.mmkv.clearAll();
  await h.bridge.restoreDriveApplicationState(snapshot);
  assert.equal(h.sql.prepare('SELECT swipe FROM chat_swipes WHERE id=4').get().swipe, text);
  assert.equal(h.sql.prepare('SELECT count(*) AS total FROM chat_swipes').get().total, 2);
  assert.equal(h.mmkv.getString('personal-prefs'), snapshot.preferences['personal-prefs']);
});

test('unknown tables and columns are rejected before SQL or cache mutation', async () => {
  const h = harness();
  const snapshot = await h.bridge.captureDriveApplicationState();
  h.directories.add(h.areas.CharacterPath);
  h.files.set(h.areas.CharacterPath + 'kept.png', 'YWJj');
  const original = h.operations.length;
  const tableAttack = clone(snapshot);
  tableAttack.tables[0].name = 'characters; DROP TABLE chats';
  await assert.rejects(h.bridge.restoreDriveApplicationState(tableAttack), /unknown or duplicate table/);
  const columnAttack = clone(snapshot);
  columnAttack.tables[0].columns[0] = 'malicious_column';
  await assert.rejects(h.bridge.restoreDriveApplicationState(columnAttack), /incompatible columns/);
  assert.equal(h.operations.length, original);
  assert.equal(h.files.get(h.areas.CharacterPath + 'kept.png'), 'YWJj');
});

test('missing tables, duplicate tables, nested cells and non-finite values are invalid', async () => {
  const h = harness();
  h.insert('characters', { id: 1, type: 'user' });
  const snapshot = await h.bridge.captureDriveApplicationState();
  const missing = clone(snapshot); missing.tables.pop();
  assert.throws(() => h.bridge.validateDriveApplicationSnapshot(missing), /incompatible/);
  const duplicate = clone(snapshot); duplicate.tables[1] = duplicate.tables[0];
  assert.throws(() => h.bridge.validateDriveApplicationSnapshot(duplicate), /duplicate/);
  for (const invalid of [{ private: 'value' }, NaN, Infinity]) {
    const corrupt = clone(snapshot);
    corrupt.tables.find((table) => table.name === 'characters').rows[0].name = invalid;
    assert.throws(() => h.bridge.validateDriveApplicationSnapshot(corrupt), /invalid characters record/);
  }
});

test('SQL-looking chat data remains a bound string and cannot execute', async () => {
  const h = harness();
  h.insert('characters', { id: 1, type: 'user', name: "'); DROP TABLE chats; --" });
  const snapshot = await h.bridge.captureDriveApplicationState();
  await h.bridge.restoreDriveApplicationState(snapshot);
  assert.equal(h.sql.prepare('SELECT name FROM characters').get().name, "'); DROP TABLE chats; --");
  assert.equal(h.sql.prepare('SELECT count(*) AS total FROM chats').get().total, 0);
});

test('SQL constraint failure rolls back all rows and does not restore preferences', async () => {
  const h = harness();
  h.insert('characters', { id: 1, type: 'user', name: 'Original person' });
  h.mmkv.set('theme', 'original');
  const snapshot = await h.bridge.captureDriveApplicationState();
  const characters = snapshot.tables.find((table) => table.name === 'characters');
  characters.rows[0].name = 'Replacement person';
  characters.rows.push(clone(characters.rows[0]));
  snapshot.preferences.theme = 'replacement';
  await assert.rejects(h.bridge.restoreDriveApplicationState(snapshot), /UNIQUE constraint failed/);
  assert.equal(h.sql.prepare('SELECT name FROM characters').get().name, 'Original person');
  assert.equal(h.mmkv.getString('theme'), 'original');
  assert.equal(h.sqliteDB.isInTransactionSync(), false);
});

test('snapshot refuses to interfere with an existing SQLite transaction', async () => {
  const h = harness();
  h.sqliteDB.execSync('BEGIN');
  h.insert('characters', { id: 1, type: 'user', name: 'Still pending' });
  await assert.rejects(h.bridge.captureDriveApplicationState(), /still finishing/);
  assert.equal(h.sqliteDB.isInTransactionSync(), true);
  assert.equal(h.sql.prepare('SELECT name FROM characters').get().name, 'Still pending');
  h.sqliteDB.execSync('COMMIT');
});

test('missing attachment and traversal filenames reject before clearing existing assets', async () => {
  const h = harness();
  h.insert('chat_attachment', { id: 1, uri: 'file:///old-phone/missing.png' });
  // Capture correctly refuses to pretend a referenced file was saved.
  await assert.rejects(h.bridge.captureDriveApplicationState(), /attachment is missing/);
  h.sql.exec('DELETE FROM chat_attachment');
  const snapshot = await h.bridge.captureDriveApplicationState();
  h.directories.add(h.areas.CharacterPath);
  h.files.set(h.areas.CharacterPath + 'kept.png', 'YWJj');
  snapshot.assets.push({ area: 'characters', name: '../escape.png', base64: 'YWJj' });
  await assert.rejects(h.bridge.restoreDriveApplicationState(snapshot), /invalid attachment or portrait/);
  assert.equal(h.files.get(h.areas.CharacterPath + 'kept.png'), 'YWJj');
});

test('attachments restore inside current phone cache, never their old device path', async () => {
  const h = harness();
  h.directories.add(h.areas.Attachments);
  h.files.set(h.areas.Attachments + 'photo.png', 'YWJj');
  h.insert('chat_attachment', { id: 1, uri: 'file:///old-phone/cache/photo.png' });
  const snapshot = await h.bridge.captureDriveApplicationState();
  await h.bridge.restoreDriveApplicationState(snapshot);
  assert.equal(h.sql.prepare('SELECT uri FROM chat_attachment').get().uri, h.areas.Attachments + 'photo.png');
  assert.equal(h.files.get(h.areas.Attachments + 'photo.png'), 'YWJj');
});

test('a verified core alone does not grant a loaded application session', async () => {
  const h = harness();
  assert.equal(h.driveMemory.getState().status, 'ready');
  assert.equal(h.bridge.isDriveSessionReady(), false);
  await assert.rejects(h.bridge.requireDriveSession(), /wait for it to load/);
  await assert.rejects(h.bridge.syncDriveDatabase(), /before saving/);
  assert.equal(h.writes.length, 0);
});

test('session change during USB verification prevents use of the stale session', async () => {
  const h = harness();
  h.bridge.activateDriveDatabaseSync();
  let resolve;
  h.driveMemory.ensureReady = () => new Promise((done) => { resolve = done; });
  const verifying = h.bridge.requireDriveSession();
  const generation = h.bridge.getDriveSessionGeneration();
  h.bridge.pauseDriveDatabaseSync();
  resolve();
  await assert.rejects(verifying, /memory drive changed/);
  assert.ok(h.bridge.getDriveSessionGeneration() > generation);
  assert.equal(h.bridge.isDriveSessionReady(), false);
});

test('explicit autosave commits full application data before reporting success', async () => {
  const h = harness();
  h.insert('characters', { id: 1, type: 'user', name: 'Drive person' });
  h.mmkv.set('font-size', 19);
  h.bridge.activateDriveDatabaseSync();
  await h.bridge.syncDriveDatabase();
  assert.equal(h.writes.length, 1);
  assert.equal(h.writes[0].preferences['font-size'], 19);
  assert.equal(h.writes[0].tables.find((table) => table.name === 'characters').rows[0].name, 'Drive person');
  await h.bridge.syncDriveDatabase();
  assert.equal(h.writes.length, 1, 'unchanged app state must not write another USB revision');
});

test('USB write failure propagates and invalidates the verified status', async () => {
  const h = harness();
  h.bridge.activateDriveDatabaseSync();
  h.driveMemory.setApplicationState = async () => { throw new Error('Drive removed while writing'); };
  await assert.rejects(h.bridge.syncDriveDatabase(), /removed while writing/);
  assert.equal(h.driveMemory.getState().status, 'unavailable');
  assert.equal(h.writes.length, 0);
});

test('deleted highest message ID is preserved across capture and fresh restore', async () => {
  const source = harness();
  source.insert('chat_entries', { id: 7, chat_id: 1, is_user: 1, name: 'User' });
  source.insert('chat_entries', { id: 20, chat_id: 1, is_user: 1, name: 'User' });
  source.sql.exec('DELETE FROM chat_entries WHERE id=20');
  const snapshot = await source.bridge.captureDriveApplicationState();
  assert.equal(snapshot.sequences.chat_entries, 20);
  const destination = harness();
  await destination.bridge.restoreDriveApplicationState(snapshot);
  const next = destination.sql.prepare('INSERT INTO chat_entries (chat_id,is_user,name,"order",swipe_id) VALUES (1,1,\'User\',0,0)').run().lastInsertRowid;
  assert.equal(next, 21, 'a deleted message ID must not be reused after reconnect');
});

test('drive switching and clearing do not inherit another drive high-water counter', async () => {
  const source = harness();
  source.insert('chat_entries', { id: 20, chat_id: 1 });
  source.sql.exec('DELETE FROM chat_entries');
  const snapshot = await source.bridge.captureDriveApplicationState();
  const destination = harness();
  destination.insert('chat_entries', { id: 400, chat_id: 1 });
  await destination.bridge.restoreDriveApplicationState(snapshot);
  const insert = destination.sql.prepare('INSERT INTO chat_entries (chat_id,is_user,name,"order",swipe_id) VALUES (1,1,\'User\',0,0)');
  assert.equal(insert.run().lastInsertRowid, 21);
  destination.bridge.clearDriveDatabase();
  assert.equal(destination.sql.prepare('SELECT count(*) AS total FROM sqlite_sequence WHERE name=\'chat_entries\'').get().total, 0);
  assert.equal(insert.run().lastInsertRowid, 1);
});

test('restored counters never fall below the maximum live row ID', async () => {
  const source = harness();
  source.insert('chat_entries', { id: 100, chat_id: 1 });
  const snapshot = await source.bridge.captureDriveApplicationState();
  snapshot.sequences.chat_entries = 1;
  const destination = harness();
  await destination.bridge.restoreDriveApplicationState(snapshot);
  const result = destination.sql.prepare('INSERT INTO chat_entries (chat_id,is_user,name,"order",swipe_id) VALUES (1,1,\'User\',0,0)').run();
  assert.equal(result.lastInsertRowid, 101);
});

test('legacy snapshots without sequence metadata remain restorable', async () => {
  const source = harness();
  source.insert('chat_entries', { id: 15, chat_id: 1 });
  const snapshot = await source.bridge.captureDriveApplicationState();
  delete snapshot.sequences;
  const destination = harness();
  await destination.bridge.restoreDriveApplicationState(snapshot);
  assert.equal(destination.sql.prepare('INSERT INTO chat_entries (chat_id,is_user,name,"order",swipe_id) VALUES (1,1,\'User\',0,0)').run().lastInsertRowid, 16);
});

test('untrusted counter table names or unsafe values reject before any mutation', async () => {
  const h = harness();
  const snapshot = await h.bridge.captureDriveApplicationState();
  h.directories.add(h.areas.CharacterPath);
  h.files.set(h.areas.CharacterPath + 'kept.png', 'YWJj');
  const before = h.operations.length;
  const unsafe = [-1, 1.5, Number.MAX_SAFE_INTEGER + 1, NaN, '20', null];
  for (const value of unsafe) {
    const corrupt = clone(snapshot); corrupt.sequences.chat_entries = value;
    await assert.rejects(h.bridge.restoreDriveApplicationState(corrupt), /invalid ID counters/);
  }
  for (const name of ['characters', 'chat_entries; DROP TABLE characters', '__proto__']) {
    const corrupt = clone(snapshot);
    Object.defineProperty(corrupt.sequences, name, { value: 20, enumerable: true });
    await assert.rejects(h.bridge.restoreDriveApplicationState(corrupt), /invalid ID counters/);
  }
  assert.equal(h.operations.length, before);
  assert.equal(h.files.get(h.areas.CharacterPath + 'kept.png'), 'YWJj');
});

test('failed restore rolls back sequence resets with the rest of the database', async () => {
  const h = harness();
  h.insert('chat_entries', { id: 40, chat_id: 1 });
  h.sql.exec('DELETE FROM chat_entries');
  h.insert('characters', { id: 1, type: 'user', name: 'Original' });
  const snapshot = await h.bridge.captureDriveApplicationState();
  snapshot.sequences.chat_entries = 99;
  const characters = snapshot.tables.find((table) => table.name === 'characters');
  characters.rows.push(clone(characters.rows[0]));
  await assert.rejects(h.bridge.restoreDriveApplicationState(snapshot), /UNIQUE constraint failed/);
  assert.equal(h.sql.prepare('SELECT seq FROM sqlite_sequence WHERE name=\'chat_entries\'').get().seq, 40);
});
