const { withAppBuildGradle, withGradleProperties } = require('@expo/config-plugins')

module.exports = function withOfflineBuild(config) {
    config = withGradleProperties(config, (c) => {
        for (const [key, value] of [
            ['EX_DEV_CLIENT_NETWORK_INSPECTOR', 'false'],
            ['reactNativeArchitectures', 'arm64-v8a'],
        ]) {
            const existing = c.modResults.find((p) => p.type === 'property' && p.key === key)
            if (existing) existing.value = value
            else c.modResults.push({ type: 'property', key, value })
        }
        return c
    })
    return withAppBuildGradle(config, (c) => {
        // Never distribute the standard public Android debug signing key.
        // A private key lives outside this source tree and is selected by path.
        let text = c.modResults.contents
        const privateSigning = `
    signingConfigs {
        if (System.getenv("CODESTICK_SIGNING_KEY") && System.getenv("CODESTICK_SIGNING_PASSWORD_FILE")) {
            offlineRelease {
                storeFile file(System.getenv("CODESTICK_SIGNING_KEY"))
                storePassword file(System.getenv("CODESTICK_SIGNING_PASSWORD_FILE")).text.trim()
                keyAlias 'ai-drive-offline'
                keyPassword file(System.getenv("CODESTICK_SIGNING_PASSWORD_FILE")).text.trim()
            }
        }
    }
`
        if (!text.includes('offlineRelease {')) {
            text = text.replace('    buildTypes {', `${privateSigning}\n    buildTypes {`)
        }
        text = text.replace(
            /release \{([\s\S]*?)signingConfig signingConfigs\.debug/,
            `release {$1if (System.getenv("CODESTICK_SIGNING_KEY") && System.getenv("CODESTICK_SIGNING_PASSWORD_FILE")) {
                signingConfig signingConfigs.offlineRelease
            }`
        )
        c.modResults.contents = text
        return c
    })
}
