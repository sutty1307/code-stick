import * as Crypto from 'expo-crypto'
import { StorageAccessFramework as SAF } from 'expo-file-system/legacy'

import { deviceGrants } from '../storage/DeviceGrants'

import { DriveAdapter, DriveMemoryCore, DriveMemoryError, FolderSettings } from './core'

const FOLDER_SETTING = 'usb-memory-folder-uri-v1'

/** Android's ExternalStorageProvider gives seekable USB/SD files, not a cloud document. */
export const validateRemovableFolder = (uri: string): void => {
    const match =
        /^content:\/\/com\.android\.externalstorage\.documents\/tree\/([^/]+)(?:\/|$)/.exec(uri)
    if (!match)
        throw new DriveMemoryError(
            'Choose a folder on the attached USB drive or removable SD card, not phone storage or a cloud provider.'
        )
    let documentId: string
    try {
        documentId = decodeURIComponent(match[1])
    } catch {
        throw new DriveMemoryError('Android returned an invalid drive folder permission.')
    }
    const volume = documentId.slice(0, documentId.indexOf(':'))
    // AOSP ExternalStorageProvider also exposes the phone's Documents directory
    // under ROOT_ID_HOME ('home:'). Its authority alone does not prove USB storage.
    if (
        !volume ||
        ['primary', 'home'].includes(volume.toLowerCase()) ||
        !documentId.includes(':')
    ) {
        throw new DriveMemoryError(
            'Choose a folder on the USB drive, not the phone’s internal storage.'
        )
    }
}
const fileName = (uri: string): string =>
    decodeURIComponent(uri.slice(uri.lastIndexOf('/') + 1))
        .split('/')
        .pop() ?? ''

export const androidDriveAdapter: DriveAdapter = {
    async selectFolder() {
        const result = await SAF.requestDirectoryPermissionsAsync()
        if (!result.granted) return undefined
        validateRemovableFolder(result.directoryUri)
        return result.directoryUri
    },
    async listFiles(folderUri) {
        validateRemovableFolder(folderUri)
        const uris = await SAF.readDirectoryAsync(folderUri)
        return uris.map((uri) => ({ uri, name: fileName(uri) }))
    },
    async readText(uri) {
        return SAF.readAsStringAsync(uri)
    },
    async createFile(folderUri, name) {
        validateRemovableFolder(folderUri)
        // SAF expects a display name without the MIME type's extension.
        const uri = await SAF.createFileAsync(
            folderUri,
            name.replace(/\.json$/, ''),
            'application/json'
        )
        if (fileName(uri) !== name)
            throw new DriveMemoryError(
                'The USB file provider did not create the expected memory filename. Use a local USB folder.'
            )
        return uri
    },
    async writeText(uri, text) {
        await SAF.writeAsStringAsync(uri, text)
    },
    async sha256(text) {
        return Crypto.digestStringAsync(Crypto.CryptoDigestAlgorithm.SHA256, text)
    },
}
export const folderSettings: FolderSettings = {
    getFolderUri: () => deviceGrants.getString(FOLDER_SETTING),
    setFolderUri: (uri) => {
        if (uri) deviceGrants.set(FOLDER_SETTING, uri)
        else deviceGrants.remove(FOLDER_SETTING)
    },
}
export const driveMemory = new DriveMemoryCore(androidDriveAdapter, folderSettings)
