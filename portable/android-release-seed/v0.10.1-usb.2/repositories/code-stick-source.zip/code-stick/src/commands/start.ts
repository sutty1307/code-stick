// Author: Muhammad Usman (MuhammadUsmanGM) | Sig: MUGM-b2e4-7f1a
import fs from "node:fs";
import path from "node:path";
import { log } from "../utils/logger.js";
import { pickDrive, assertDriveReady } from "../core/usb.js";
import { usbPaths } from "../utils/paths.js";
import { hostTarget, resolveEngineTarget, makeBinaryProbe } from "../utils/platform.js";
import { ollamaBinaryRel } from "../catalog/ollama.js";
import { opencodeBinaryRel } from "../catalog/opencode.js";
import { loadManifest, defaultModel } from "../state/manifest.js";
import { inspectOllamaData, hasOllamaTagManifest } from "../core/health.js";
import {
  startOllama, waitForOllama, runOpencodeForeground,
  stopAll, setupShutdownHooks, checkPortFree,
} from "../core/process-manager.js";

interface StartOptions { target?: string; }

export async function startCommand(opts: StartOptions): Promise<void> {
  setupShutdownHooks();
  log.banner("Start");

  const drivePath = await pickDrive(opts.target);
  assertDriveReady(drivePath);

  const manifest = loadManifest(drivePath);
  if (!manifest) {
    log.error(`No code-stick installation found at ${drivePath}.`);
    log.info("Run: code-stick install");
    process.exit(1);
  }

  const p = usbPaths(drivePath);
  // Match the start-windows.bat runtime fallback: a Windows ARM64 host can
  // run x64 binaries under Prism, a macOS ARM64 host can run x64 under
  // Rosetta. If the native target isn't staged but an emulatable fallback
  // is, use it instead of erroring out. Linux ARM↔x64 has no fast emulation,
  // so resolveEngineTarget will throw with an actionable add-targets remedy.
  const native = hostTarget();
  let target: typeof native;
  try {
    target = resolveEngineTarget(
      manifest.targets,
      makeBinaryProbe((t) => p.engine(t), ollamaBinaryRel),
    );
  } catch (err) {
    log.error((err as Error).message);
    process.exit(1);
  }
  if (target !== native) {
    log.warn(`Native target ${native} not staged on this stick — falling back to ${target} (emulated).`);
  }
  const ollamaBin = path.join(p.engine(target), ollamaBinaryRel(target));
  const opencodeBin = path.join(p.opencode(target), opencodeBinaryRel(target));

  if (!fs.existsSync(ollamaBin)) {
    log.error(`Ollama binary missing for resolved target (${target}): ${ollamaBin}`);
    log.info(`Re-run: code-stick upgrade-engine --target "${drivePath}"`);
    process.exit(1);
  }
  if (!fs.existsSync(opencodeBin)) {
    log.error(`opencode binary missing for resolved target (${target}): ${opencodeBin}`);
    log.info(`Re-run: code-stick upgrade-engine --target "${drivePath}"`);
    process.exit(1);
  }

  const health = inspectOllamaData(p.data);
  if (!health.hasModelData) {
    log.error("Model store on USB is empty or incomplete.");
    log.info(`Re-run: code-stick install --target "${drivePath}"`);
    process.exit(1);
  }

  await checkPortFree();

  const def = defaultModel(manifest);
  if (!def) {
    log.error("This stick has no models. Add one before launching:");
    log.info(`  code-stick add-model --target "${drivePath}"`);
    process.exit(1);
  }
  // The manifest says we have this tag; verify ollama actually has its
  // manifest blob on disk. Catches the case where blobs/ exists from another
  // model but the default model's tag was never fully pulled (or got removed
  // on disk while remaining in the JSON manifest).
  if (!hasOllamaTagManifest(p.data, def.tag)) {
    log.error(`Default model "${def.tag}" is in the manifest but its ollama tag is missing from the model store.`);
    log.info(`Re-pull it: code-stick add-model ${def.id} --target "${drivePath}"`);
    process.exit(1);
  }
  const otherCount = manifest.models.length - 1;
  log.info(`Model: ${def.tag}${otherCount > 0 ? ` (+${otherCount} other on stick)` : ""}`);
  log.dim(`Starting Ollama from USB (target: ${target})...`);
  startOllama(drivePath, target);
  const ready = await waitForOllama(45_000);
  if (!ready) {
    log.error("Ollama did not become ready in time.");
    await stopAll();
    process.exit(1);
  }
  log.success("Ollama is ready");
  log.blank();
  log.info("Launching opencode (Ctrl+C to quit)...");
  log.blank();

  let exitCode = 0;
  try {
    exitCode = await runOpencodeForeground(drivePath, target);
  } finally {
    await stopAll();
  }
  process.exit(exitCode);
}
