# AI Drive Offline 0.10.1-usb.4

Modified on 2026-10-15.

This update waits for asynchronous SDK 57 file copies before reading imported
default-character and tokenizer files or publishing copied portraits,
backgrounds and chat attachments. The shared copy helper catches asynchronous
copy failures, and dependent operations stop before using a failed copy. Android
versionCode advances from 3 to 4 so the existing app can update with the same signing key.

The previous update fixes shorter USB snapshot replacements on Android storage providers
that do not truncate writes. A save deletes and recreates only the inactive
snapshot document before writing and verifying it; the active verified snapshot
stays untouched. File identity checks reject aliases to that active snapshot,
unexpected replacement filenames and directories. Failed writes still produce a
visible error with no phone or cloud fallback.

The previous update fixed both “Choose a model” navigation paths: the chat input
action and the current-model link open the model manager through the router.

This user-requested Android fork adds removable-drive persistence and an offline toolkit to the pinned ChatterUI source. It installs as `com.codestick.aidrive` and is independently signed. The upstream AGPL license and notices remain in `LICENSE` and the original source files.

The app removes Android internet/network-state permission, forces Local mode, disables online updates and speech-provider calls, and excludes personal content from Android backup. User settings and SQLite tables run in RAM. Complete application snapshots, SQLite identity counters, histories and alternate replies, preferences, facts, notes, profiles, and cached picture/attachment assets save through the removable-folder service. Internal `primary:` and `home:` folders and cloud providers are rejected. Save/disconnect and drive changes clear private RAM/cache.

The selected USB folder contains plaintext, checksum-protected dual recovery snapshots. Verified saves require exact read-back. Read-back is not a filesystem flush guarantee. There is no automatic phone/cloud fallback. Snapshot and entry limits produce visible errors rather than silently truncating stored histories. The model receives bounded memory reference text, not every saved historic message at once.

Only explicit user commands run the arithmetic/memory/note toolkit; saved text and model replies cannot execute commands. Forgotten memory retains source markers to prevent old history from recreating it. Complete conversation deletion is separate from forgetting a fact.

Use Node 24, the existing lockfile, and `npm ci`. Verification commands:

```sh
node node_modules/typescript/bin/tsc --noEmit
node --test lib/driveMemory/core.test.cjs lib/driveMemory/android.test.cjs tests/drive-bridge.test.cjs tests/file-copy.test.cjs
node node_modules/jest/bin/jest.js --config lib/driveTools/jest.config.cjs --runInBand
node node_modules/jest/bin/jest.js --config lib/storage/session-values.jest.config.cjs --runInBand
node node_modules/jest/bin/jest.js --config lib/engine/DataSources/drive-memory-source.jest.config.cjs --runInBand
```

The default upstream Jest Expo configuration is unsuitable for these pure-module tests; the focused configs isolate native dependencies. Bridge tests exercise the real bundled Drizzle schema against Node SQLite, while Android storage APIs are simulated. See `BUILD-ANDROID-OFFLINE.md` for native and matching-publisher-runtime build paths. Release keys and password files must stay outside source archives.

Software tests, compilation, signature and manifest checks do not establish real Android/USB compatibility. Physical installation, inference, storage grants, detach/reconnect, corruption/power-loss recovery and performance need device validation before selling a kit.

Built with Llama.
