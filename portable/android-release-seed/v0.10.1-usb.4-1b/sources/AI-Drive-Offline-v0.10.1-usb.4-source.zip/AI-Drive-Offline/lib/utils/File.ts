import { localDownload } from '@vali98/react-native-fs'
import { getDocumentAsync } from 'expo-document-picker'
import { Directory, File, FileMode, Paths } from 'expo-file-system'

import { Logger } from '../state/Logger'

export const AppDirectory = {
    ModelPath: `${Paths.document.uri}models/`,
    SessionPath: `${Paths.cache.uri}session/`,
    CharacterPath: `${Paths.cache.uri}characters/`,
    Assets: `${Paths.cache.uri}appAssets/`,
    Attachments: `${Paths.cache.uri}attachments/`,
}

export namespace FileUtils {
    export const getDocumentDir = (dir: string) => {
        return `${Paths.document.uri}${dir}`
    }

    export const getCacheDir = (dir: string) => {
        return `${Paths.cache.uri}${dir}`
    }

    /**
     *
     * @param data string data of file
     * @param filename filename to be written, include extension
     * @param encoding encoding of file
     */
    export const saveStringToDownload = async (
        data: string,
        filename: string,
        encoding: 'base64' | `utf8`
    ) => {
        new File(Paths.cache, filename).write(data, { encoding })
        await localDownload((Paths.cache.uri + filename).replace('file://', '')).catch((e) =>
            Logger.error('Failed to download: ' + e)
        )
    }

    export const pickText = async (params: { type?: string } = {}): Promise<PickerResult> => {
        return pickFile(async (file) => {
            return await file.text()
        }, params)
    }

    export const pickBase64 = async (params: { type?: string } = {}): Promise<PickerResult> => {
        return pickFile(async (file) => {
            return await file.base64()
        }, params)
    }

    export const pickJSON = async (params: { type?: string } = {}): Promise<PickerResult> => {
        const result = await pickText(params)
        if (!result.success) return result
        try {
            return { success: true, data: JSON.parse(result.data) }
        } catch {
            return { success: false }
        }
    }

    const pickFile = async (
        fileReader: (file: File) => Promise<string>,
        { type = '*/*' }: { type?: string } = {}
    ): Promise<PickerResult> => {
        const result = await getDocumentAsync({ type: type })
        if (result.canceled) {
            return { success: false }
        }
        const [asset] = result.assets
        const file = new File(asset.uri)
        let data = await fileReader(file)
        if (!data) {
            return { success: false }
        }
        return { success: true, data: data }
    }
}

export const saveStringToDownload = async (
    data: string,
    filename: string,
    encoding: 'base64' | `utf8`
) => {
    new File(Paths.cache, filename).write(data, { encoding })
    await localDownload((Paths.cache.uri + filename).replace('file://', '')).catch((e) =>
        Logger.error('Failed to download: ' + e)
    )
}

type PickerResult = { success: false } | { success: true; data: string }

type JSONPickerResult = { success: false } | { success: true; data: any }

/**@deprecated */
export const pickJSONDocument = async (): Promise<JSONPickerResult> => {
    const result = await pickStringDocument({ type: 'application/json' })
    if (!result.success) return result
    try {
        const jsonData = JSON.parse(result.data)
        return { success: true, data: jsonData }
    } catch {
        return { success: false }
    }
}

/**@deprecated */
export const pickStringDocument = async ({
    encoding = 'utf8',
    type = '*/*',
}: {
    encoding?: 'utf8' | 'base64'
    type?: string
} = {}): Promise<PickerResult> => {
    const result = await getDocumentAsync({ type: type })
    if (result.canceled) {
        return { success: false }
    }
    const uri = result.assets[0].uri
    const file = new File(uri)
    let data = ''
    if (encoding === 'utf8') data = await file.text()
    else data = await file.base64()

    if (!data) {
        return { success: false }
    }
    return { success: true, data: data }
}

const gb = 1000 ** 3
const mb = 1000 ** 2

/**
 * Gets a human friendly version of file size
 * @param size size in bytes
 * @returns string containing readable file size
 */
export const readableFileSize = (size: number) => {
    if (size < gb) {
        const sizeInMB = size / mb
        return `${sizeInMB.toFixed(2)} MB`
    } else {
        const sizeInGB = size / gb
        return `${sizeInGB.toFixed(2)} GB`
    }
}

export const listFiles = (path: string) => {
    return new Directory(path)
        .listAsRecords()
        .filter((item) => !item.isDirectory)
        .map((item) => {
            const uri = item.uri.endsWith('/') ? item.uri.slice(0, -1) : item.uri
            return uri.slice(uri.lastIndexOf('/') + 1)
        })
        .filter((item): item is string => !!item)
}

export const fileExists = (path: string) => {
    return new File(path).exists
}

export const directoryExists = (path: string) => {
    return new Directory(path).exists
}

export const copyFile = async ({ from, to }: { from: string; to: string }) => {
    try {
        await new File(from).copy(new File(to))
        return true
    } catch (e) {
        Logger.error('Failed to copy: ' + e)
        return false
    }
}

export const deleteFile = (path: string) => {
    try {
        const file = new File(path)
        if (file.exists) file.delete()
        return true
    } catch (e) {
        Logger.error('Failed to delete: ' + e)
        return false
    }
}

export const readBase64Async = async (path: string) => {
    return await new File(path).base64()
}

export const readStringAsync = async (path: string) => {
    return await new File(path).text()
}

export const writeBase64File = async (path: string, content: string) => {
    return await new File(path).write(content, { encoding: 'base64' })
}

export const fileInfo = (path: string) => {
    return new File(path).info()
}

export const makeDirectory = async (path: string) => {
    new Directory(path).create({ idempotent: true })
}

export const readFileMagic = (path: string) => {
    const magicBytes = new File(path).open(FileMode.ReadOnly).readBytes(4)
    const magic = String.fromCharCode(...magicBytes)
    const hex = Array.from(magic, (b) => `0x${b.toString().padStart(2, '0').toUpperCase()}`).join(
        ' '
    )

    return { hex, magic }
}

export const printFileMagic = (path: string) => {
    const { hex, magic } = readFileMagic(path)
    Logger.info(hex)
    Logger.info(magic)
}
