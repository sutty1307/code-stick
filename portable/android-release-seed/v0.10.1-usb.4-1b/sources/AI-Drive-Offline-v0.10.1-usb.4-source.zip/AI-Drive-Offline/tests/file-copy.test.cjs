// Runs trusted application functions with controlled native copy promises. The
// deferred copies expose reads and published references before bytes exist.
const { test } = require('node:test')
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const ts = require('typescript')

const root = process.env.AI_DRIVE_COPY_TEST_SOURCE_ROOT || path.resolve(__dirname, '..')
const tick = () => new Promise((resolve) => setImmediate(resolve))

function compile(source, filename, dependencies = {}) {
    const compiled = ts.transpileModule(source, {
        compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
        fileName: filename,
    }).outputText
    const runtime = { exports: {} }
    const req = (name) => {
        if (Object.prototype.hasOwnProperty.call(dependencies, name)) return dependencies[name]
        throw new Error('Unexpected test dependency: ' + name)
    }
    new Function('require', 'module', 'exports', compiled)(req, runtime, runtime.exports)
    return runtime.exports
}

// Extract the real named function rather than recreating its implementation.
// Other state stores/native modules in these files are outside this test scope.
function applicationFunction(relative, name, globals) {
    const filename = path.join(root, relative)
    const source = ts.createSourceFile(
        filename,
        fs.readFileSync(filename, 'utf8'),
        ts.ScriptTarget.Latest
    )
    const matches = []
    const visit = (node) => {
        if (
            (ts.isVariableDeclaration(node) || ts.isPropertyAssignment(node)) &&
            node.name.getText(source) === name &&
            node.initializer &&
            (ts.isArrowFunction(node.initializer) || ts.isFunctionExpression(node.initializer))
        )
            matches.push(node.initializer.getText(source))
        ts.forEachChild(node, visit)
    }
    visit(source)
    assert.equal(matches.length, 1, 'Expected exactly one real function: ' + name)
    const compiled = ts.transpileModule('module.exports = ' + matches[0], {
        compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
    }).outputText
    const runtime = { exports: {} }
    new Function(...Object.keys(globals), 'module', compiled)(...Object.values(globals), runtime)
    return runtime.exports
}

function harness() {
    let resolveCopy, rejectCopy
    const gate = new Promise((resolve, reject) => {
        resolveCopy = resolve
        rejectCopy = reject
    })
    const sourceUri = 'file:///cache/ExponentAsset-source.raw'
    const files = new Map([[sourceUri, 'complete asset bytes']])
    const operations = []
    const errors = []
    const logger = {
        info: () => {},
        infoToast: () => operations.push('success-toast'),
        error: (error) => errors.push(String(error)),
        errorToast: (error) => errors.push(String(error)),
    }
    class File {
        constructor(uri) {
            this.uri = String(uri)
        }
        get exists() {
            return files.has(this.uri)
        }
        copy(destination) {
            operations.push('copy-start')
            return gate.then(() => {
                files.set(destination.uri, files.get(this.uri))
                operations.push('copy-finished')
            })
        }
    }
    const paths = { cache: { uri: 'file:///cache/' }, document: { uri: 'file:///documents/' } }
    const filename = path.join(root, 'lib/utils/File.ts')
    const file = compile(fs.readFileSync(filename, 'utf8'), filename, {
        '@vali98/react-native-fs': {},
        'expo-document-picker': {},
        'expo-file-system': { File, Directory: class {}, FileMode: {}, Paths: paths },
        '../state/Logger': { Logger: logger },
    })
    return { file, files, sourceUri, operations, errors, logger, paths, resolveCopy, rejectCopy }
}

function defaultCard(h, asset = { localUri: h.sourceUri }) {
    return applicationFunction('lib/state/Characters.ts', 'createDefaultCard', {
        Paths: h.paths,
        fileExists: h.file.fileExists,
        Asset: { loadAsync: async () => [asset] },
        require: () => 'packaged-default-card',
        copyFile: h.file.copyFile,
        createCharacterFromImage: async (uri) => {
            assert.equal(
                h.files.get(uri),
                'complete asset bytes',
                'PNG read requires completed copy'
            )
            h.operations.push('parse-png')
        },
        Logger: h.logger,
        t: (key) => key,
    })
}

test('copy helper waits for native bytes before reporting success', async () => {
    const h = harness()
    let finished = false
    const result = h.file
        .copyFile({ from: h.sourceUri, to: 'file:///cache/copied.raw' })
        .then((value) => {
            finished = true
            return value
        })
    await tick()
    try {
        assert.equal(finished, false)
        assert.equal(h.files.has('file:///cache/copied.raw'), false)
    } finally {
        h.resolveCopy()
    }
    assert.equal(await result, true)
    assert.equal(h.files.get('file:///cache/copied.raw'), 'complete asset bytes')
})

test('copy helper catches an asynchronous native rejection and reports failure', async () => {
    const h = harness()
    const result = h.file.copyFile({ from: h.sourceUri, to: 'file:///cache/copied.raw' })
    h.rejectCopy(new Error('device copy failed'))
    assert.equal(await result, false)
    assert.equal(h.files.has('file:///cache/copied.raw'), false)
    assert.match(h.errors.join(' '), /device copy failed/)
})

test('default character reads its PNG only after the real helper finishes copying', async () => {
    const h = harness()
    const result = defaultCard(h)()
    await tick()
    try {
        assert.deepEqual(h.operations, ['copy-start'])
    } finally {
        h.resolveCopy()
    }
    await result
    assert.deepEqual(h.operations, ['copy-start', 'copy-finished', 'parse-png'])
    assert.deepEqual(h.errors, [])
})

test('default character never parses a rejected copy and reports the import failure', async () => {
    const h = harness()
    const result = defaultCard(h)()
    await tick()
    h.rejectCopy(new Error('asset copy rejected'))
    await result
    assert.equal(h.operations.includes('parse-png'), false)
    assert.match(h.errors.join(' '), /Failed to copy the default character asset/)
})

test('default character reports a missing packaged asset without reading a nonexistent PNG', async () => {
    const h = harness()
    await defaultCard(h, { localUri: null })()
    assert.deepEqual(h.operations, [])
    assert.match(h.errors.join(' '), /default character asset is unavailable/)
})

test('portrait copy completion includes its underlying native write', async () => {
    const h = harness()
    const copyImage = applicationFunction('lib/state/Characters.ts', 'copyImage', {
        copyFile: h.file.copyFile,
        getImageDir: (id) => 'file:///cache/characters/' + id + '.png',
    })
    let finished = false
    const result = copyImage(h.sourceUri, 42).then(() => {
        finished = true
    })
    await tick()
    try {
        assert.equal(finished, false)
    } finally {
        h.resolveCopy()
    }
    await result
    assert.equal(h.files.get('file:///cache/characters/42.png'), 'complete asset bytes')
})

test('portrait copy rejects when the native asset copy fails', async () => {
    const h = harness()
    const copyImage = applicationFunction('lib/state/Characters.ts', 'copyImage', {
        copyFile: h.file.copyFile,
        getImageDir: (id) => 'file:///cache/characters/' + id + '.png',
    })
    const result = copyImage(h.sourceUri, 42)
    h.rejectCopy(new Error('portrait unavailable'))
    await assert.rejects(result, /Failed to copy character image/)
})

function tokenizerImport(h) {
    return applicationFunction('lib/engine/Tokenizer.ts', 'importModelFromRes', {
        fileExists: h.file.fileExists,
        tokenizerModelDir: 'file:///cache/appAssets/llama3tokenizer.gguf',
        Logger: h.logger,
        Asset: {
            loadAsync: async () => [{ localUri: h.sourceUri, downloadAsync: async () => {} }],
        },
        require: () => 'packaged-tokenizer',
        copyFile: h.file.copyFile,
    })
}

test('tokenizer import cannot finish before the copied model is readable', async () => {
    const h = harness()
    let finished = false
    const result = tokenizerImport(h)().then(() => {
        finished = true
    })
    await tick()
    try {
        assert.equal(finished, false)
    } finally {
        h.resolveCopy()
    }
    await result
    assert.equal(
        h.files.get('file:///cache/appAssets/llama3tokenizer.gguf'),
        'complete asset bytes'
    )
})

test('tokenizer import rejects an unsuccessful native copy', async () => {
    const h = harness()
    const result = tokenizerImport(h)()
    await tick()
    h.rejectCopy(new Error('tokenizer unavailable'))
    await assert.rejects(result, /Failed to copy tokenizer asset/)
})

function backgroundImport(h) {
    return applicationFunction('lib/state/BackgroundImage.ts', 'importImage', {
        getDocumentAsync: async () => ({
            canceled: false,
            assets: [{ uri: h.sourceUri, name: 'background.png' }],
        }),
        copyFile: h.file.copyFile,
        AppDirectory: h.file.AppDirectory,
        set: () => h.operations.push('publish-background'),
        Logger: h.logger,
        t: (key) => key,
    })
}

test('background settings and success are published only after completed bytes', async () => {
    const h = harness()
    const result = backgroundImport(h)()
    await tick()
    try {
        assert.deepEqual(h.operations, ['copy-start'])
    } finally {
        h.resolveCopy()
    }
    await result
    assert.deepEqual(h.operations, [
        'copy-start',
        'copy-finished',
        'publish-background',
        'success-toast',
    ])
})

test('background copy rejection does not publish a broken preference or success', async () => {
    const h = harness()
    const result = backgroundImport(h)()
    await tick()
    h.rejectCopy(new Error('background unavailable'))
    await result
    assert.deepEqual(h.operations, ['copy-start'])
    assert.match(h.errors.join(' '), /Failed to copy background image/)
})

function attachmentImport(h) {
    return applicationFunction('lib/state/Chat.ts', 'createAttachment', {
        randomUUID: () => 'attachment-id',
        fileInfo: () => ({ exists: true }),
        mime: { getType: () => 'image/png' },
        validExtensionTypes: () => true,
        AppDirectory: h.file.AppDirectory,
        copyFile: h.file.copyFile,
        database: {
            insert: () => ({
                values: () => ({
                    returning: async () => {
                        h.operations.push('insert-attachment')
                        return [{ id: 1 }]
                    },
                }),
            }),
        },
        chatAttachments: {},
        Logger: h.logger,
        t: (key) => key,
    })
}

test('attachment rows are inserted only after the referenced copied file exists', async () => {
    const h = harness()
    const result = attachmentImport(h)(1, h.sourceUri)
    await tick()
    try {
        assert.deepEqual(h.operations, ['copy-start'])
    } finally {
        h.resolveCopy()
    }
    assert.deepEqual(await result, { id: 1 })
    assert.deepEqual(h.operations, ['copy-start', 'copy-finished', 'insert-attachment'])
})

test('attachment rejection reports failure without inserting a broken file reference', async () => {
    const h = harness()
    const result = attachmentImport(h)(1, h.sourceUri)
    await tick()
    h.rejectCopy(new Error('attachment unavailable'))
    assert.equal(await result, undefined)
    assert.deepEqual(h.operations, ['copy-start'])
    assert.match(h.errors.join(' '), /common.errors.failedToCopy/)
})
