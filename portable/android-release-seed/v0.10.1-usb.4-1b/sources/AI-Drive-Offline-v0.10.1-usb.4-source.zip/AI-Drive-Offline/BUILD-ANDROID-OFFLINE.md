# Building AI Drive Offline

This fork uses the upstream ChatterUI 0.10.0 source, its locked dependencies and
the matching ChatterUI 0.10.1 native runtime. The independent Android application
ID is `com.codestick.aidrive`; it can coexist with stock ChatterUI. The production
manifest removes `INTERNET` and `ACCESS_NETWORK_STATE`, disables Android app
backup and disables Expo updates. The release bundle contains the application
code, so it does not require a development server or cloud service.

## Native source build

Install the exact dependencies with `npm ci`. Use JDK 17+, Android platform 36,
build-tools 36.0.0, NDK 27.1.12297006 and CMake 3.22.1. Expo/Gradle may also request
NDK 27.0.12077973 for SQLite. Set `JAVA_HOME` and `ANDROID_HOME`, then run:

```sh
./scripts/build-offline-android.sh
```

For a signed release, generate and securely retain your own private key with the
alias `ai-drive-offline`. Keep it outside this source directory and USB kit. Set
`CODESTICK_SIGNING_KEY` to its path and `CODESTICK_SIGNING_PASSWORD_FILE` to a
private file containing its password. Without these variables the release is
unsigned. Never distribute a build signed with the standard Android debug key.
Verify the resulting APK's manifest, signature and functionality before release.

The cloud setup successfully installed the toolchain and completed Gradle
preflight. Native assembly could not retrieve Maven dependencies because the
managed proxy returned HTTP 503 transport errors. Proxy settings and TLS
verification were preserved.

## Rebuilding with the matching publisher native shell

`scripts/rebuild-publisher-shell.py` provides a second build path. It compiles the
modified source into a production Metro/Hermes bundle and places it into the
verified publisher native shell, updates assets/configuration and the manifest,
then signs the independent fork. It does not recompile native code.

The pinned publisher APK is available from:

<https://github.com/Vali-98/ChatterUI/releases/download/v0.10.0/ChatterUI_v0.10.1.apk>

SHA-256: `ec051d90bc9f82587a726b525976494bacef50bc8a7dd0e3789b859373121753`

```sh
python scripts/rebuild-publisher-shell.py \
  --publisher-apk /path/to/ChatterUI_v0.10.1.apk \
  --apktool /path/to/apktool_2.12.1.jar \
  --android-build-tools /path/to/android-sdk/build-tools/36.0.0 \
  --keystore /private/path/to/ai-drive-offline.p12 \
  --password-file /private/path/to/keystore.password \
  --output /path/to/AI-Drive-Offline_v0.10.1-usb.4.apk
```

The script checks the pinned APK, React Native 0.86.3, Expo SDK 57 and Hermes
bytecode 98 compatibility, APK signature, ZIP integrity/alignment, ARM64/minimum
SDK 24 and absence of networking permissions. It verifies every publisher DEX
file and native library remains byte-for-byte unchanged. A `.build.json` file
records the resulting binary provenance. Native React Native 0.86.3 was
independently confirmed from the publisher DEX's exported version constants.

Both build paths use existing native APIs. Adding a new native dependency or
changing a locked native package requires a complete native source build.
Build checks do not establish actual Android phone/USB hardware compatibility.

Keep the AGPL license, upstream notices and corresponding modified source with
any distributed application. Exclude `node_modules/`, generated `android/`,
temporary build outputs and every signing key/password from a source archive.
